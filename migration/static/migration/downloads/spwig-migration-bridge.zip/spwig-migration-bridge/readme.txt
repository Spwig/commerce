=== Spwig Migration Bridge ===
Contributors: spwig
Tags: migration, affiliate, woocommerce, spwig
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Exposes WooCommerce affiliate plugin data via REST API for seamless migration to Spwig eCommerce platform.

== Description ==

Spwig Migration Bridge is a lightweight, read-only plugin that enables merchants to migrate their affiliate program data from WooCommerce to the Spwig eCommerce platform.

**Supported Affiliate Plugins:**

* AffiliateWP
* Affiliate for WooCommerce (by StoreApps)

**What It Does:**

* Auto-detects which affiliate plugin is installed
* Exposes affiliate data through a secure REST API
* Uses your existing WooCommerce API keys for authentication
* Reads data only — never modifies your affiliate tables
* Provides a status page showing detected plugin and record counts

**Data Exposed:**

* Affiliate profiles and user data
* Commission/referral records with order IDs
* Commission plan structures
* Payout history
* Click/visit tracking data

**How to Use:**

1. Install and activate this plugin on your WooCommerce store
2. In your Spwig admin panel, open the Affiliate Import Wizard
3. Enter your store URL and WooCommerce API keys
4. Preview and import your affiliate data
5. Deactivate this plugin when done

== Installation ==

1. Upload the `spwig-migration-bridge` folder to `/wp-content/plugins/`
2. Activate the plugin through the Plugins menu
3. Navigate to WooCommerce > Spwig Migration to verify detection
4. Ensure you have WooCommerce REST API keys with Read permissions

== Frequently Asked Questions ==

= Does this plugin modify my affiliate data? =

No. The plugin is completely read-only. It only reads data from your affiliate plugin's database tables and exposes it via the REST API.

= What authentication does it use? =

It uses your existing WooCommerce REST API consumer key and secret. No additional credentials needed.

= Can I remove it after migration? =

Yes. Once your affiliate data has been imported into Spwig, you can safely deactivate and delete this plugin. It only stores its own version option and a detection cache transient, both of which are cleaned up on uninstall.

== Changelog ==

= 1.0.0 =
* Initial release
* Support for AffiliateWP and Affiliate for WooCommerce
* REST API endpoints: info, affiliates, referrals, plans, payouts, hits
* Admin status page under WooCommerce menu
