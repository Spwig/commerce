<?php
/**
 * Plugin Name: Spwig Migration Bridge
 * Plugin URI: https://spwig.com/migration
 * Description: Exposes affiliate data via REST API for migration to Spwig eCommerce platform. Supports AffiliateWP and Affiliate for WooCommerce.
 * Version: 1.0.0
 * Author: Spwig
 * Author URI: https://spwig.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: spwig-migration-bridge
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'SPWIG_BRIDGE_VERSION', '1.0.0' );
define( 'SPWIG_BRIDGE_FILE', __FILE__ );
define( 'SPWIG_BRIDGE_DIR', plugin_dir_path( __FILE__ ) );
define( 'SPWIG_BRIDGE_URL', plugin_dir_url( __FILE__ ) );

/**
 * Check WooCommerce is active before loading.
 */
function spwig_bridge_check_dependencies() {
    if ( ! class_exists( 'WooCommerce' ) ) {
        add_action( 'admin_notices', function () {
            echo '<div class="error"><p>';
            esc_html_e(
                'Spwig Migration Bridge requires WooCommerce to be installed and active.',
                'spwig-migration-bridge'
            );
            echo '</p></div>';
        } );
        return false;
    }
    return true;
}

/**
 * Initialize plugin after all plugins have loaded.
 */
function spwig_bridge_init() {
    if ( ! spwig_bridge_check_dependencies() ) {
        return;
    }

    // Load includes
    require_once SPWIG_BRIDGE_DIR . 'includes/class-spwig-plugin-detector.php';
    require_once SPWIG_BRIDGE_DIR . 'includes/class-spwig-auth.php';
    Spwig_Auth::init();
    require_once SPWIG_BRIDGE_DIR . 'includes/class-spwig-rest-controller.php';
    require_once SPWIG_BRIDGE_DIR . 'includes/class-spwig-info-controller.php';
    require_once SPWIG_BRIDGE_DIR . 'includes/class-spwig-affiliates-controller.php';
    require_once SPWIG_BRIDGE_DIR . 'includes/class-spwig-referrals-controller.php';
    require_once SPWIG_BRIDGE_DIR . 'includes/class-spwig-plans-controller.php';
    require_once SPWIG_BRIDGE_DIR . 'includes/class-spwig-payouts-controller.php';
    require_once SPWIG_BRIDGE_DIR . 'includes/class-spwig-hits-controller.php';
    require_once SPWIG_BRIDGE_DIR . 'includes/adapters/interface-spwig-affiliate-adapter.php';
    require_once SPWIG_BRIDGE_DIR . 'includes/adapters/class-affiliatewp-adapter.php';
    require_once SPWIG_BRIDGE_DIR . 'includes/adapters/class-afwc-adapter.php';

    // Load admin page
    if ( is_admin() ) {
        require_once SPWIG_BRIDGE_DIR . 'admin/class-spwig-admin-page.php';
        new Spwig_Admin_Page();
    }
}
add_action( 'plugins_loaded', 'spwig_bridge_init', 20 );

/**
 * Register REST API routes.
 */
function spwig_bridge_register_routes() {
    if ( ! class_exists( 'WooCommerce' ) ) {
        return;
    }

    $controllers = array(
        new Spwig_Info_Controller(),
        new Spwig_Affiliates_Controller(),
        new Spwig_Referrals_Controller(),
        new Spwig_Plans_Controller(),
        new Spwig_Payouts_Controller(),
        new Spwig_Hits_Controller(),
    );

    foreach ( $controllers as $controller ) {
        $controller->register_routes();
    }
}
add_action( 'rest_api_init', 'spwig_bridge_register_routes' );

/**
 * Activation hook.
 */
function spwig_bridge_activate() {
    if ( ! class_exists( 'WooCommerce' ) ) {
        wp_die(
            esc_html__(
                'Spwig Migration Bridge requires WooCommerce to be installed and active.',
                'spwig-migration-bridge'
            ),
            'Plugin Activation Error',
            array( 'back_link' => true )
        );
    }

    update_option( 'spwig_bridge_version', SPWIG_BRIDGE_VERSION );
    update_option( 'spwig_bridge_activated_at', current_time( 'mysql' ) );
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'spwig_bridge_activate' );

/**
 * Deactivation hook.
 */
function spwig_bridge_deactivate() {
    delete_transient( 'spwig_bridge_detected_plugin' );
    flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'spwig_bridge_deactivate' );
