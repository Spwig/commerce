<?php
/**
 * Spwig Migration Bridge - Uninstall
 *
 * Removes plugin options and transients. Does not touch affiliate data.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

delete_option( 'spwig_bridge_version' );
delete_option( 'spwig_bridge_activated_at' );
delete_transient( 'spwig_bridge_detected_plugin' );
