<?php
/**
 * Admin Status Page
 *
 * Adds a "Spwig Migration" submenu under WooCommerce showing
 * detected affiliate plugin, record counts, and API base URL.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Spwig_Admin_Page {

	/**
	 * Hook into WordPress admin.
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu_page' ), 60 );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	/**
	 * Register submenu page under WooCommerce.
	 */
	public function add_menu_page() {
		add_submenu_page(
			'woocommerce',
			__( 'Spwig Migration Bridge', 'spwig-migration-bridge' ),
			__( 'Spwig Migration', 'spwig-migration-bridge' ),
			'manage_woocommerce',
			'spwig-migration-bridge',
			array( $this, 'render_page' )
		);
	}

	/**
	 * Enqueue admin CSS on our page only.
	 *
	 * @param string $hook The current admin page hook.
	 */
	public function enqueue_assets( $hook ) {
		if ( 'woocommerce_page_spwig-migration-bridge' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'spwig-admin',
			SPWIG_BRIDGE_URL . 'assets/css/admin.css',
			array(),
			SPWIG_BRIDGE_VERSION
		);
	}

	/**
	 * Render the status page.
	 */
	public function render_page() {
		// Force fresh detection
		Spwig_Plugin_Detector::clear_cache();
		$detected = Spwig_Plugin_Detector::detect();
		$adapter  = Spwig_Plugin_Detector::get_adapter();

		$counts = array(
			'affiliates' => 0,
			'referrals'  => 0,
			'plans'      => 0,
			'payouts'    => 0,
			'hits'       => 0,
		);

		if ( $adapter ) {
			$counts = $adapter->get_counts();
		}

		$api_base = rest_url( 'spwig/v1/' );
		$currency = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD';

		include SPWIG_BRIDGE_DIR . 'admin/views/admin-status.php';
	}
}
