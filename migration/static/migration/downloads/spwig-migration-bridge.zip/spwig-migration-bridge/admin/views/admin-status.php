<?php
/**
 * Admin Status Page Template
 *
 * Variables available: $detected, $adapter, $counts, $api_base, $currency
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$is_detected  = 'none' !== $detected['plugin'];
$status_class = $is_detected ? 'spwig-status-ok' : 'spwig-status-error';
$status_icon  = $is_detected ? '&#10003;' : '&#10007;';
?>
<div class="wrap spwig-admin-wrap">
	<h1><?php esc_html_e( 'Spwig Migration Bridge', 'spwig-migration-bridge' ); ?></h1>
	<p class="spwig-version">
		<?php
		printf(
			/* translators: %s: plugin version */
			esc_html__( 'Version %s', 'spwig-migration-bridge' ),
			esc_html( SPWIG_BRIDGE_VERSION )
		);
		?>
	</p>

	<!-- Plugin Detection Status -->
	<div class="spwig-card">
		<h2><?php esc_html_e( 'Affiliate Plugin Detection', 'spwig-migration-bridge' ); ?></h2>
		<div class="spwig-status-row <?php echo esc_attr( $status_class ); ?>">
			<span class="spwig-status-icon"><?php echo $status_icon; // phpcs:ignore ?></span>
			<div class="spwig-status-detail">
				<strong>
					<?php
					if ( $is_detected ) {
						echo esc_html( $detected['name'] );
						if ( $detected['version'] ) {
							echo ' <span class="spwig-version-badge">v' . esc_html( $detected['version'] ) . '</span>';
						}
					} else {
						esc_html_e( 'No supported affiliate plugin detected', 'spwig-migration-bridge' );
					}
					?>
				</strong>
				<p>
					<?php
					if ( $is_detected ) {
						esc_html_e( 'Plugin detected and ready for data export.', 'spwig-migration-bridge' );
					} else {
						esc_html_e(
							'Install AffiliateWP or Affiliate for WooCommerce to enable data export.',
							'spwig-migration-bridge'
						);
					}
					?>
				</p>
			</div>
		</div>
	</div>

	<?php if ( $is_detected ) : ?>
	<!-- Record Counts -->
	<div class="spwig-card">
		<h2><?php esc_html_e( 'Available Data', 'spwig-migration-bridge' ); ?></h2>
		<table class="spwig-counts-table widefat">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Data Type', 'spwig-migration-bridge' ); ?></th>
					<th><?php esc_html_e( 'Records', 'spwig-migration-bridge' ); ?></th>
					<th><?php esc_html_e( 'API Endpoint', 'spwig-migration-bridge' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><?php esc_html_e( 'Affiliates', 'spwig-migration-bridge' ); ?></td>
					<td><strong><?php echo esc_html( number_format_i18n( $counts['affiliates'] ) ); ?></strong></td>
					<td><code>/spwig/v1/affiliates</code></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'Commissions', 'spwig-migration-bridge' ); ?></td>
					<td><strong><?php echo esc_html( number_format_i18n( $counts['referrals'] ) ); ?></strong></td>
					<td><code>/spwig/v1/referrals</code></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'Plans', 'spwig-migration-bridge' ); ?></td>
					<td><strong><?php echo esc_html( number_format_i18n( $counts['plans'] ) ); ?></strong></td>
					<td><code>/spwig/v1/plans</code></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'Payouts', 'spwig-migration-bridge' ); ?></td>
					<td><strong><?php echo esc_html( number_format_i18n( $counts['payouts'] ) ); ?></strong></td>
					<td><code>/spwig/v1/payouts</code></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'Clicks / Visits', 'spwig-migration-bridge' ); ?></td>
					<td><strong><?php echo esc_html( number_format_i18n( $counts['hits'] ) ); ?></strong></td>
					<td><code>/spwig/v1/hits</code></td>
				</tr>
			</tbody>
		</table>
	</div>

	<!-- API Information -->
	<div class="spwig-card">
		<h2><?php esc_html_e( 'API Information', 'spwig-migration-bridge' ); ?></h2>
		<table class="spwig-info-table widefat">
			<tbody>
				<tr>
					<td><?php esc_html_e( 'API Base URL', 'spwig-migration-bridge' ); ?></td>
					<td><code><?php echo esc_html( $api_base ); ?></code></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'Store Currency', 'spwig-migration-bridge' ); ?></td>
					<td><strong><?php echo esc_html( $currency ); ?></strong></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'Authentication', 'spwig-migration-bridge' ); ?></td>
					<td><?php esc_html_e( 'WooCommerce REST API keys (consumer key + secret)', 'spwig-migration-bridge' ); ?></td>
				</tr>
			</tbody>
		</table>
	</div>
	<?php endif; ?>

	<!-- Help Box -->
	<div class="spwig-card spwig-help-card">
		<h2><?php esc_html_e( 'How It Works', 'spwig-migration-bridge' ); ?></h2>
		<ol>
			<li><?php esc_html_e( 'This plugin reads your affiliate data (read-only) and exposes it via a secure REST API.', 'spwig-migration-bridge' ); ?></li>
			<li>
				<?php
				printf(
					/* translators: %s: WooCommerce REST API settings URL */
					esc_html__( 'Ensure you have WooCommerce REST API keys with at least "Read" permissions. Create them at %s.', 'spwig-migration-bridge' ),
					'<a href="' . esc_url( admin_url( 'admin.php?page=wc-settings&tab=advanced&section=keys' ) ) . '">' .
					esc_html__( 'WooCommerce > Settings > Advanced > REST API', 'spwig-migration-bridge' ) .
					'</a>'
				);
				?>
			</li>
			<li><?php esc_html_e( 'In your Spwig admin panel, use the Affiliate Import Wizard and enter your store URL along with the API keys.', 'spwig-migration-bridge' ); ?></li>
			<li><?php esc_html_e( 'The wizard will connect to this plugin, preview available data, and import your affiliate records.', 'spwig-migration-bridge' ); ?></li>
			<li><?php esc_html_e( 'Once migration is complete, you can safely deactivate and remove this plugin.', 'spwig-migration-bridge' ); ?></li>
		</ol>
	</div>
</div>
