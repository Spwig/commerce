<?php
/**
 * Referrals Controller
 *
 * GET /spwig/v1/referrals — returns paginated commission/referral records
 * with order IDs for relinking, normalized across AffiliateWP and AFWC.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Spwig_Referrals_Controller extends Spwig_REST_Controller {

	/**
	 * @var string
	 */
	protected $rest_base = 'referrals';

	/**
	 * Register routes.
	 */
	public function register_routes() {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base,
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_items' ),
					'permission_callback' => array( $this, 'check_permissions' ),
					'args'                => $this->get_collection_params(),
				),
			)
		);
	}

	/**
	 * Handle GET /spwig/v1/referrals.
	 *
	 * @param WP_REST_Request $request The incoming request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_items( $request ) {
		$adapter = $this->get_adapter();
		if ( ! $adapter ) {
			return new WP_Error(
				'spwig_no_adapter',
				__( 'No affiliate plugin adapter available.', 'spwig-migration-bridge' ),
				array( 'status' => 503 )
			);
		}

		$params = $this->get_pagination_params( $request );
		$result = $adapter->get_referrals( $params['per_page'], $params['offset'] );

		return $this->paginated_response(
			$result['items'],
			$result['total'],
			$params['page'],
			$params['per_page']
		);
	}
}
