<?php
/**
 * Base REST Controller
 *
 * Provides shared pagination, authentication, and response helpers
 * for all Spwig Migration Bridge endpoints.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

abstract class Spwig_REST_Controller extends WP_REST_Controller {

    /**
     * REST API namespace.
     *
     * @var string
     */
    protected $namespace = 'spwig/v1';

    /**
     * Default items per page.
     */
    const DEFAULT_PER_PAGE = 100;

    /**
     * Maximum items per page.
     */
    const MAX_PER_PAGE = 100;

    /**
     * Permission callback: authenticate via WC consumer keys and verify an adapter is available.
     *
     * @param WP_REST_Request $request The incoming request.
     * @return true|WP_Error
     */
    public function check_permissions( $request ) {
        $auth_result = Spwig_Auth::authenticate( $request );

        if ( is_wp_error( $auth_result ) ) {
            return $auth_result;
        }

        $detected = Spwig_Plugin_Detector::detect();
        if ( 'none' === $detected['plugin'] ) {
            return new WP_Error(
                'spwig_no_affiliate_plugin',
                __(
                    'No supported affiliate plugin detected. Please install AffiliateWP or Affiliate for WooCommerce.',
                    'spwig-migration-bridge'
                ),
                array( 'status' => 503 )
            );
        }

        return true;
    }

    /**
     * Extract pagination parameters from the request.
     *
     * @param WP_REST_Request $request The incoming request.
     * @return array { page: int, per_page: int, offset: int }
     */
    protected function get_pagination_params( $request ) {
        $page     = max( 1, absint( $request->get_param( 'page' ) ) ?: 1 );
        $per_page = min(
            self::MAX_PER_PAGE,
            max( 1, absint( $request->get_param( 'per_page' ) ) ?: self::DEFAULT_PER_PAGE )
        );
        $offset = ( $page - 1 ) * $per_page;

        return compact( 'page', 'per_page', 'offset' );
    }

    /**
     * Create a paginated response with standard WP REST API headers.
     *
     * Uses X-WP-Total and X-WP-TotalPages headers which the Spwig
     * migration client already knows how to parse.
     *
     * @param array $items    Items for the current page.
     * @param int   $total    Total number of items across all pages.
     * @param int   $page     Current page number.
     * @param int   $per_page Items per page.
     * @return WP_REST_Response
     */
    protected function paginated_response( $items, $total, $page, $per_page ) {
        $total_pages = max( 1, (int) ceil( $total / $per_page ) );

        $response = new WP_REST_Response( $items, 200 );
        $response->header( 'X-WP-Total', (int) $total );
        $response->header( 'X-WP-TotalPages', (int) $total_pages );
        $response->header( 'X-Spwig-Bridge-Version', SPWIG_BRIDGE_VERSION );

        return $response;
    }

    /**
     * Get the adapter instance (lazy-loaded, cached per request).
     *
     * @return Spwig_Affiliate_Adapter_Interface|null
     */
    protected function get_adapter() {
        static $adapter = null;
        if ( null === $adapter ) {
            $adapter = Spwig_Plugin_Detector::get_adapter();
        }
        return $adapter;
    }

    /**
     * Register common collection query parameters for list endpoints.
     *
     * @return array
     */
    public function get_collection_params() {
        return array(
            'page'     => array(
                'description'       => __( 'Current page of the collection.', 'spwig-migration-bridge' ),
                'type'              => 'integer',
                'default'           => 1,
                'minimum'           => 1,
                'sanitize_callback' => 'absint',
            ),
            'per_page' => array(
                'description'       => __( 'Maximum number of items per page.', 'spwig-migration-bridge' ),
                'type'              => 'integer',
                'default'           => self::DEFAULT_PER_PAGE,
                'minimum'           => 1,
                'maximum'           => self::MAX_PER_PAGE,
                'sanitize_callback' => 'absint',
            ),
        );
    }
}
