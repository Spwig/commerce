<?php
/**
 * Authentication Handler
 *
 * Validates REST API requests using WooCommerce consumer key/secret.
 * Piggybacks on the existing WC API key infrastructure so merchants
 * don't need to generate separate credentials.
 *
 * WC hashes consumer keys with hash_hmac('sha256', $key, 'wc-api').
 * We must use the same algorithm to look up keys.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Spwig_Auth {

	/**
	 * Stored auth error from early filter, if any.
	 *
	 * @var WP_Error|null
	 */
	private static $auth_error = null;

	/**
	 * Whether we've already authenticated for this request.
	 *
	 * @var bool
	 */
	private static $authenticated = false;

	/**
	 * Register auth filters.
	 */
	public static function init() {
		add_filter( 'determine_current_user', array( __CLASS__, 'authenticate_on_our_routes' ), 5 );
		add_filter( 'rest_authentication_errors', array( __CLASS__, 'clear_auth_errors_for_our_routes' ), 999 );
	}

	/**
	 * Clear any auth errors set by WordPress core or other plugins for our endpoints.
	 *
	 * @param WP_Error|null|true $error The authentication error (null = no error).
	 * @return WP_Error|null|true
	 */
	public static function clear_auth_errors_for_our_routes( $error ) {
		if ( ! self::is_spwig_request() ) {
			return $error;
		}

		// If we stored an auth error from our own validation, return it
		if ( self::$auth_error ) {
			return self::$auth_error;
		}

		// Clear any external errors for our namespace
		return null;
	}

	/**
	 * Early filter on determine_current_user.
	 *
	 * When the request is to our /spwig/v1/ namespace and uses HTTP Basic Auth
	 * with WC consumer keys (ck_*), authenticate via WC keys and return the
	 * associated WP user ID.
	 *
	 * @param int|false $user_id The current user ID (0 or false if not set).
	 * @return int|false
	 */
	public static function authenticate_on_our_routes( $user_id ) {
		if ( $user_id ) {
			return $user_id;
		}

		if ( ! self::is_spwig_request() ) {
			return $user_id;
		}

		// Extract Basic Auth credentials using same approach as WooCommerce
		$credentials = self::extract_basic_auth();
		if ( ! $credentials ) {
			return $user_id;
		}

		$consumer_key    = $credentials['key'];
		$consumer_secret = $credentials['secret'];

		// Only handle WC consumer keys
		if ( 'ck_' !== substr( $consumer_key, 0, 3 ) ) {
			return $user_id;
		}

		$result = self::validate_wc_credentials( $consumer_key, $consumer_secret );
		if ( is_wp_error( $result ) ) {
			self::$auth_error = $result;
			return 0;
		}

		self::$authenticated = true;
		return $result; // WP user_id
	}

	/**
	 * Authenticate the REST request using WooCommerce consumer keys.
	 *
	 * Called from the permission callback of each endpoint.
	 *
	 * @param WP_REST_Request $request The incoming request.
	 * @return true|WP_Error True on success, WP_Error on failure.
	 */
	public static function authenticate( $request ) {
		if ( self::$auth_error ) {
			return self::$auth_error;
		}

		if ( self::$authenticated && get_current_user_id() > 0 ) {
			return true;
		}

		// Try query string parameters (not handled by early filter)
		$consumer_key    = sanitize_text_field( $request->get_param( 'consumer_key' ) );
		$consumer_secret = sanitize_text_field( $request->get_param( 'consumer_secret' ) );

		if ( ! empty( $consumer_key ) && ! empty( $consumer_secret ) ) {
			if ( 'ck_' !== substr( $consumer_key, 0, 3 ) ) {
				return new WP_Error(
					'spwig_auth_invalid_key',
					__( 'Invalid consumer key format. Expected a WooCommerce consumer key starting with ck_.', 'spwig-migration-bridge' ),
					array( 'status' => 401 )
				);
			}

			$result = self::validate_wc_credentials( $consumer_key, $consumer_secret );
			if ( is_wp_error( $result ) ) {
				return $result;
			}

			wp_set_current_user( $result );
			return true;
		}

		return new WP_Error(
			'spwig_auth_missing',
			__( 'Authentication required. Provide WooCommerce consumer key and secret via HTTP Basic Auth or query parameters.', 'spwig-migration-bridge' ),
			array( 'status' => 401 )
		);
	}

	/**
	 * Extract Basic Auth credentials from the request.
	 *
	 * Checks multiple sources (matching WooCommerce's approach):
	 * 1. PHP_AUTH_USER / PHP_AUTH_PW (Apache)
	 * 2. HTTP_AUTHORIZATION $_SERVER variable
	 * 3. REDIRECT_HTTP_AUTHORIZATION $_SERVER variable (CGI/FastCGI)
	 * 4. getallheaders() function (nginx fallback)
	 *
	 * @return array|false { key: string, secret: string } or false.
	 */
	private static function extract_basic_auth() {
		$consumer_key    = '';
		$consumer_secret = '';

		// Method 1: PHP_AUTH_USER/PW (set by Apache)
		if ( ! empty( $_SERVER['PHP_AUTH_USER'] ) && ! empty( $_SERVER['PHP_AUTH_PW'] ) ) {
			$consumer_key    = sanitize_text_field( wp_unslash( $_SERVER['PHP_AUTH_USER'] ) );
			$consumer_secret = sanitize_text_field( wp_unslash( $_SERVER['PHP_AUTH_PW'] ) );
		} else {
			// Get the Authorization header from any available source
			$auth_header = self::get_authorization_header();

			if ( $auth_header && 0 === strpos( $auth_header, 'Basic ' ) ) {
				// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
				$decoded = base64_decode( substr( $auth_header, 6 ) );
				if ( $decoded && false !== strpos( $decoded, ':' ) ) {
					list( $consumer_key, $consumer_secret ) = explode( ':', $decoded, 2 );
					$consumer_key    = sanitize_text_field( $consumer_key );
					$consumer_secret = sanitize_text_field( $consumer_secret );
				}
			}
		}

		if ( empty( $consumer_key ) || empty( $consumer_secret ) ) {
			return false;
		}

		return array(
			'key'    => $consumer_key,
			'secret' => $consumer_secret,
		);
	}

	/**
	 * Get the Authorization header from any available source.
	 *
	 * Mirrors WooCommerce's approach: $_SERVER vars first, then getallheaders()
	 * as a fallback for nginx and other servers that don't populate PHP_AUTH_*.
	 *
	 * @return string Authorization header value or empty string.
	 */
	private static function get_authorization_header() {
		// Check standard $_SERVER variables
		if ( ! empty( $_SERVER['HTTP_AUTHORIZATION'] ) ) {
			return sanitize_text_field( wp_unslash( $_SERVER['HTTP_AUTHORIZATION'] ) );
		}

		if ( ! empty( $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ) ) {
			return sanitize_text_field( wp_unslash( $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ) );
		}

		// Fallback: getallheaders() works on nginx where $_SERVER vars may not be set
		if ( function_exists( 'getallheaders' ) ) {
			$headers = getallheaders();
			if ( is_array( $headers ) ) {
				// Header names are case-insensitive per RFC 7230
				foreach ( $headers as $key => $value ) {
					if ( 'authorization' === strtolower( $key ) ) {
						return sanitize_text_field( $value );
					}
				}
			}
		}

		// Last resort: apache_request_headers()
		if ( function_exists( 'apache_request_headers' ) ) {
			$headers = apache_request_headers();
			if ( is_array( $headers ) ) {
				foreach ( $headers as $key => $value ) {
					if ( 'authorization' === strtolower( $key ) ) {
						return sanitize_text_field( $value );
					}
				}
			}
		}

		return '';
	}

	/**
	 * Validate credentials against the WooCommerce API keys table.
	 *
	 * WC hashes consumer keys using hash_hmac('sha256', $key, 'wc-api').
	 *
	 * @param string $consumer_key    The consumer key (ck_xxx).
	 * @param string $consumer_secret The consumer secret (cs_xxx).
	 * @return int|WP_Error WP user_id on success, WP_Error on failure.
	 */
	private static function validate_wc_credentials( $consumer_key, $consumer_secret ) {
		global $wpdb;

		if ( function_exists( 'wc_api_hash' ) ) {
			$hashed_key = wc_api_hash( $consumer_key );
		} else {
			$hashed_key = hash_hmac( 'sha256', $consumer_key, 'wc-api' );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$key_data = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT key_id, user_id, permissions, consumer_secret
				 FROM {$wpdb->prefix}woocommerce_api_keys
				 WHERE consumer_key = %s",
				$hashed_key
			)
		);

		if ( ! $key_data ) {
			return new WP_Error(
				'spwig_auth_key_not_found',
				__( 'Consumer key not recognized. Ensure you are using a valid WooCommerce REST API key.', 'spwig-migration-bridge' ),
				array( 'status' => 401 )
			);
		}

		if ( ! hash_equals( $key_data->consumer_secret, $consumer_secret ) ) {
			return new WP_Error(
				'spwig_auth_secret_mismatch',
				__( 'Consumer secret is incorrect.', 'spwig-migration-bridge' ),
				array( 'status' => 401 )
			);
		}

		if ( ! in_array( $key_data->permissions, array( 'read', 'read_write' ), true ) ) {
			return new WP_Error(
				'spwig_auth_insufficient_permissions',
				__( 'API key requires at least read permissions.', 'spwig-migration-bridge' ),
				array( 'status' => 403 )
			);
		}

		return (int) $key_data->user_id;
	}

	/**
	 * Check if the current request is to our REST namespace.
	 *
	 * @return bool
	 */
	private static function is_spwig_request() {
		if ( empty( $_SERVER['REQUEST_URI'] ) ) {
			return false;
		}

		$request_uri = sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) );

		if ( false !== strpos( $request_uri, '/spwig/v1' ) ) {
			return true;
		}

		if ( isset( $_GET['rest_route'] ) ) {
			$route = sanitize_text_field( wp_unslash( $_GET['rest_route'] ) );
			if ( 0 === strpos( $route, '/spwig/v1' ) ) {
				return true;
			}
		}

		return false;
	}
}
