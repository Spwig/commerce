<?php
/**
 * Affiliate for WooCommerce (AFWC) Adapter
 *
 * Queries wp_afwc_* custom tables and WP user meta to expose
 * affiliate data in the unified Spwig Bridge format.
 *
 * Table reference (from cocosbotanica inspection):
 *   wp_afwc_referrals        — commissions (affiliate_id, post_id=order, amount, status)
 *   wp_afwc_hits             — click tracking
 *   wp_afwc_commission_plans — plan objects with JSON rules
 *   wp_afwc_payouts          — payout records
 *   wp_afwc_payout_orders    — M2M payout↔referral linkage
 *   wp_afwc_campaigns        — marketing campaigns
 *
 * AFWC referral status codes: 0=pending, 1=approved, 2=paid, 3=rejected
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Spwig_AFWC_Adapter implements Spwig_Affiliate_Adapter_Interface {

	/**
	 * Map AFWC numeric referral status to unified string.
	 */
	private static $status_map = array(
		0 => 'pending',
		1 => 'approved',
		2 => 'paid',
		3 => 'rejected',
	);

	/**
	 * {@inheritdoc}
	 */
	public function get_counts() {
		global $wpdb;

		$prefix = $wpdb->prefix;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery
		$affiliates = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$wpdb->usermeta}
			 WHERE meta_key = 'afwc_is_affiliate' AND meta_value = 'yes'"
		);

		$referrals = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$prefix}afwc_referrals" );
		$plans     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$prefix}afwc_commission_plans" );
		$payouts   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$prefix}afwc_payouts" );
		$hits      = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$prefix}afwc_hits" );
		// phpcs:enable

		return array(
			'affiliates' => $affiliates,
			'referrals'  => $referrals,
			'plans'      => $plans,
			'payouts'    => $payouts,
			'hits'       => $hits,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_affiliates( $limit, $offset ) {
		global $wpdb;

		// Total count
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$total = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$wpdb->usermeta}
			 WHERE meta_key = 'afwc_is_affiliate' AND meta_value = 'yes'"
		);

		// Get affiliate user IDs with pagination
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$user_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT user_id FROM {$wpdb->usermeta}
				 WHERE meta_key = 'afwc_is_affiliate' AND meta_value = 'yes'
				 ORDER BY user_id ASC
				 LIMIT %d OFFSET %d",
				$limit,
				$offset
			)
		);

		$items = array();
		foreach ( $user_ids as $user_id ) {
			$user = get_userdata( (int) $user_id );
			if ( ! $user ) {
				continue;
			}

			$meta = get_user_meta( (int) $user_id );

			// Determine status from user meta
			$status = 'active';
			if ( isset( $meta['afwc_is_affiliate'][0] ) && 'yes' !== $meta['afwc_is_affiliate'][0] ) {
				$status = 'inactive';
			}

			// Payment email: check for PayPal email in meta, fallback to user email
			$payment_email = '';
			if ( ! empty( $meta['afwc_paypal_email'][0] ) ) {
				$payment_email = $meta['afwc_paypal_email'][0];
			}

			// Commission info from user meta (per-affiliate override)
			$commission_type  = 'percentage';
			$commission_value = 0;
			if ( ! empty( $meta['afwc_commission_type'][0] ) ) {
				$commission_type = $meta['afwc_commission_type'][0];
			}
			if ( ! empty( $meta['afwc_commission_value'][0] ) ) {
				$commission_value = (float) $meta['afwc_commission_value'][0];
			}

			// Affiliate code / referral ID
			$affiliate_code = '';
			if ( ! empty( $meta['afwc_ref_url_id'][0] ) ) {
				$affiliate_code = $meta['afwc_ref_url_id'][0];
			}

			// Signup date
			$signup_date = '';
			if ( ! empty( $meta['afwc_signup_date'][0] ) ) {
				$signup_date = $meta['afwc_signup_date'][0];
			}

			// Additional fields (JSON stored)
			$additional = array();
			if ( ! empty( $meta['afwc_additional_fields'][0] ) ) {
				$decoded = maybe_unserialize( $meta['afwc_additional_fields'][0] );
				if ( is_array( $decoded ) ) {
					$additional = $decoded;
				}
			}

			$items[] = array(
				'source_id'        => (int) $user_id,
				'wp_user_id'       => (int) $user_id,
				'email'            => $user->user_email,
				'first_name'       => $user->first_name,
				'last_name'        => $user->last_name,
				'display_name'     => $user->display_name,
				'payment_email'    => $payment_email,
				'status'           => $status,
				'commission_type'  => $commission_type,
				'commission_value' => $commission_value,
				'affiliate_code'   => $affiliate_code,
				'signup_date'      => $signup_date,
				'website'          => $user->user_url,
				'additional_fields' => $additional,
				'registered_date'  => $user->user_registered,
			);
		}

		return array(
			'items' => $items,
			'total' => $total,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_referrals( $limit, $offset ) {
		global $wpdb;

		$table = $wpdb->prefix . 'afwc_referrals';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} ORDER BY referral_id ASC LIMIT %d OFFSET %d",
				$limit,
				$offset
			)
		);

		$currency = get_woocommerce_currency();
		$items    = array();

		foreach ( $rows as $row ) {
			$items[] = array(
				'source_id'    => (int) $row->referral_id,
				'affiliate_id' => (int) $row->affiliate_id,
				'order_id'     => (int) $row->post_id,
				'amount'       => (float) $row->amount,
				'currency'     => $currency,
				'status'       => isset( self::$status_map[ (int) $row->status ] )
					? self::$status_map[ (int) $row->status ]
					: 'pending',
				'type'         => isset( $row->type ) ? $row->type : 'sale',
				'description'  => isset( $row->description ) ? $row->description : '',
				'created_at'   => isset( $row->datetime ) ? $row->datetime : '',
				'campaign_id'  => isset( $row->campaign_id ) ? (int) $row->campaign_id : 0,
			);
		}

		return array(
			'items' => $items,
			'total' => $total,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_plans( $limit, $offset ) {
		global $wpdb;

		$table = $wpdb->prefix . 'afwc_commission_plans';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} ORDER BY id ASC LIMIT %d OFFSET %d",
				$limit,
				$offset
			)
		);

		$items = array();
		foreach ( $rows as $row ) {
			// AFWC stores rules as serialized PHP or JSON
			$rules = array();
			if ( ! empty( $row->rules ) ) {
				$decoded = maybe_unserialize( $row->rules );
				if ( ! is_array( $decoded ) ) {
					$decoded = json_decode( $row->rules, true );
				}
				if ( is_array( $decoded ) ) {
					$rules = $decoded;
				}
			}

			$items[] = array(
				'source_id'        => (int) $row->id,
				'name'             => isset( $row->name ) ? $row->name : 'Plan #' . $row->id,
				'commission_type'  => isset( $row->type ) ? $row->type : 'percentage',
				'commission_value' => isset( $row->commission ) ? (float) $row->commission : 0,
				'rules'            => $rules,
				'status'           => isset( $row->status ) ? $row->status : 'active',
				'priority'         => isset( $row->priority ) ? (int) $row->priority : 0,
			);
		}

		return array(
			'items' => $items,
			'total' => $total,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_payouts( $limit, $offset ) {
		global $wpdb;

		$table = $wpdb->prefix . 'afwc_payouts';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} ORDER BY payout_id ASC LIMIT %d OFFSET %d",
				$limit,
				$offset
			)
		);

		$currency       = get_woocommerce_currency();
		$orders_table   = $wpdb->prefix . 'afwc_payout_orders';
		$items          = array();

		foreach ( $rows as $row ) {
			// Get linked referral IDs from the M2M table
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$referral_ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT referral_id FROM {$orders_table} WHERE payout_id = %d",
					$row->payout_id
				)
			);

			$items[] = array(
				'source_id'    => (int) $row->payout_id,
				'affiliate_id' => (int) $row->affiliate_id,
				'amount'       => (float) $row->amount,
				'currency'     => $currency,
				'method'       => isset( $row->payment_method ) ? $row->payment_method : 'manual',
				'status'       => 'completed',
				'referral_ids' => array_map( 'intval', $referral_ids ),
				'created_at'   => isset( $row->datetime ) ? $row->datetime : '',
			);
		}

		return array(
			'items' => $items,
			'total' => $total,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_hits( $limit, $offset ) {
		global $wpdb;

		$table = $wpdb->prefix . 'afwc_hits';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} ORDER BY id ASC LIMIT %d OFFSET %d",
				$limit,
				$offset
			)
		);

		$items = array();
		foreach ( $rows as $row ) {
			$items[] = array(
				'source_id'    => (int) $row->id,
				'affiliate_id' => (int) $row->affiliate_id,
				'url'          => isset( $row->url ) ? $row->url : '',
				'referrer'     => isset( $row->referrer ) ? $row->referrer : '',
				'ip_address'   => isset( $row->ip ) ? $row->ip : '',
				'user_agent'   => isset( $row->user_agent ) ? $row->user_agent : '',
				'created_at'   => isset( $row->datetime ) ? $row->datetime : '',
				'type'         => isset( $row->type ) ? $row->type : 'click',
			);
		}

		return array(
			'items' => $items,
			'total' => $total,
		);
	}
}
