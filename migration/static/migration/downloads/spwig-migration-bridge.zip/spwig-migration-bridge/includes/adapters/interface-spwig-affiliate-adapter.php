<?php
/**
 * Affiliate Adapter Interface
 *
 * Defines the contract that all affiliate plugin adapters must implement.
 * Each method returns array( 'items' => array, 'total' => int ) for pagination.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface Spwig_Affiliate_Adapter_Interface {

	/**
	 * Get record counts for all data types.
	 *
	 * @return array {
	 *     @type int $affiliates
	 *     @type int $referrals
	 *     @type int $plans
	 *     @type int $payouts
	 *     @type int $hits
	 * }
	 */
	public function get_counts();

	/**
	 * Get affiliate profiles with WP user data.
	 *
	 * @param int $limit  Number of items to return.
	 * @param int $offset Offset for pagination.
	 * @return array { items: array, total: int }
	 *
	 * Each item contains:
	 *   source_id, wp_user_id, email, first_name, last_name,
	 *   payment_email, status, commission_type, commission_value,
	 *   affiliate_code, signup_date, website
	 */
	public function get_affiliates( $limit, $offset );

	/**
	 * Get commission/referral records.
	 *
	 * @param int $limit  Number of items to return.
	 * @param int $offset Offset for pagination.
	 * @return array { items: array, total: int }
	 *
	 * Each item contains:
	 *   source_id, affiliate_id, order_id, amount, currency,
	 *   status, type, description, created_at
	 */
	public function get_referrals( $limit, $offset );

	/**
	 * Get commission plan structures.
	 *
	 * @param int $limit  Number of items to return.
	 * @param int $offset Offset for pagination.
	 * @return array { items: array, total: int }
	 *
	 * Each item contains:
	 *   source_id, name, commission_type, commission_value,
	 *   rules, status
	 */
	public function get_plans( $limit, $offset );

	/**
	 * Get payout history.
	 *
	 * @param int $limit  Number of items to return.
	 * @param int $offset Offset for pagination.
	 * @return array { items: array, total: int }
	 *
	 * Each item contains:
	 *   source_id, affiliate_id, amount, currency, method,
	 *   status, referral_ids, created_at
	 */
	public function get_payouts( $limit, $offset );

	/**
	 * Get click/visit tracking data.
	 *
	 * @param int $limit  Number of items to return.
	 * @param int $offset Offset for pagination.
	 * @return array { items: array, total: int }
	 *
	 * Each item contains:
	 *   source_id, affiliate_id, url, referrer,
	 *   ip_address, user_agent, created_at
	 */
	public function get_hits( $limit, $offset );
}
