<?php
/**
 * AffiliateWP Adapter
 *
 * Queries wp_affiliate_wp_* custom tables and WP user data to expose
 * affiliate data in the unified Spwig Bridge format.
 *
 * AffiliateWP table reference:
 *   wp_affiliate_wp_affiliates  — affiliate profiles (affiliate_id, user_id, rate, rate_type, status)
 *   wp_affiliate_wp_referrals   — commissions (affiliate_id, reference=order_id, amount, status)
 *   wp_affiliate_wp_visits      — click tracking
 *   wp_affiliate_wp_payouts     — payout records
 *   wp_affiliate_wp_creatives   — marketing creatives/banners
 *
 * AffiliateWP referral statuses: pending, unpaid, paid, rejected
 * Unified mapping: pending→pending, unpaid→approved, paid→paid, rejected→rejected
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Spwig_AffiliateWP_Adapter implements Spwig_Affiliate_Adapter_Interface {

	/**
	 * Map AffiliateWP referral status to unified string.
	 */
	private static $status_map = array(
		'pending'  => 'pending',
		'unpaid'   => 'approved',
		'paid'     => 'paid',
		'rejected' => 'rejected',
	);

	/**
	 * Map AffiliateWP affiliate status to unified string.
	 */
	private static $affiliate_status_map = array(
		'active'   => 'active',
		'inactive' => 'inactive',
		'pending'  => 'pending',
		'rejected' => 'rejected',
	);

	/**
	 * {@inheritdoc}
	 */
	public function get_counts() {
		global $wpdb;

		$prefix = $wpdb->prefix . 'affiliate_wp_';

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery
		$affiliates = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$prefix}affiliates" );
		$referrals  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$prefix}referrals" );
		$payouts    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$prefix}payouts" );
		$hits       = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$prefix}visits" );
		// phpcs:enable

		// AffiliateWP doesn't have a plans table — plans are synthesized from
		// distinct rate/rate_type combinations + global defaults.
		$plans = $this->count_synthesized_plans();

		return array(
			'affiliates' => $affiliates,
			'referrals'  => $referrals,
			'plans'      => $plans,
			'payouts'    => $payouts,
			'hits'       => $hits,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_affiliates( $limit, $offset ) {
		global $wpdb;

		$table = $wpdb->prefix . 'affiliate_wp_affiliates';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} ORDER BY affiliate_id ASC LIMIT %d OFFSET %d",
				$limit,
				$offset
			)
		);

		$items = array();
		foreach ( $rows as $row ) {
			$user = get_userdata( (int) $row->user_id );
			if ( ! $user ) {
				continue;
			}

			$payment_email = '';
			if ( ! empty( $row->payment_email ) ) {
				$payment_email = $row->payment_email;
			}

			$status = isset( self::$affiliate_status_map[ $row->status ] )
				? self::$affiliate_status_map[ $row->status ]
				: $row->status;

			// Rate type: percentage or flat
			$commission_type  = ! empty( $row->rate_type ) ? $row->rate_type : 'percentage';
			$commission_value = ! empty( $row->rate ) ? (float) $row->rate : 0;

			// If no per-affiliate rate, use global default
			if ( empty( $row->rate ) ) {
				$commission_value = (float) affiliate_wp()->settings->get( 'referral_rate', 20 );
			}
			if ( empty( $row->rate_type ) ) {
				$commission_type = affiliate_wp()->settings->get( 'referral_rate_type', 'percentage' );
			}

			$items[] = array(
				'source_id'        => (int) $row->affiliate_id,
				'wp_user_id'       => (int) $row->user_id,
				'email'            => $user->user_email,
				'first_name'       => $user->first_name,
				'last_name'        => $user->last_name,
				'display_name'     => $user->display_name,
				'payment_email'    => $payment_email,
				'status'           => $status,
				'commission_type'  => $commission_type,
				'commission_value' => $commission_value,
				'affiliate_code'   => '',
				'signup_date'      => isset( $row->date_registered ) ? $row->date_registered : '',
				'website'          => $user->user_url,
				'additional_fields' => array(),
				'registered_date'  => $user->user_registered,
				'earnings'         => isset( $row->earnings ) ? (float) $row->earnings : 0,
				'unpaid_earnings'  => isset( $row->unpaid_earnings ) ? (float) $row->unpaid_earnings : 0,
				'referral_count'   => isset( $row->referrals ) ? (int) $row->referrals : 0,
				'visit_count'      => isset( $row->visits ) ? (int) $row->visits : 0,
			);
		}

		return array(
			'items' => $items,
			'total' => $total,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_referrals( $limit, $offset ) {
		global $wpdb;

		$table = $wpdb->prefix . 'affiliate_wp_referrals';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} ORDER BY referral_id ASC LIMIT %d OFFSET %d",
				$limit,
				$offset
			)
		);

		$currency = get_woocommerce_currency();
		$items    = array();

		foreach ( $rows as $row ) {
			$status = isset( self::$status_map[ $row->status ] )
				? self::$status_map[ $row->status ]
				: 'pending';

			$items[] = array(
				'source_id'    => (int) $row->referral_id,
				'affiliate_id' => (int) $row->affiliate_id,
				'order_id'     => ! empty( $row->reference ) ? (int) $row->reference : 0,
				'amount'       => (float) $row->amount,
				'currency'     => ! empty( $row->currency ) ? $row->currency : $currency,
				'status'       => $status,
				'type'         => isset( $row->type ) ? $row->type : 'sale',
				'description'  => isset( $row->description ) ? $row->description : '',
				'created_at'   => isset( $row->date ) ? $row->date : '',
				'campaign_id'  => isset( $row->campaign ) ? (int) $row->campaign : 0,
				'context'      => isset( $row->context ) ? $row->context : '',
			);
		}

		return array(
			'items' => $items,
			'total' => $total,
		);
	}

	/**
	 * {@inheritdoc}
	 *
	 * AffiliateWP doesn't have a plans table. We synthesize plans from:
	 * 1. Distinct rate/rate_type combinations across affiliates
	 * 2. The global default rate from WP options
	 */
	public function get_plans( $limit, $offset ) {
		$plans = $this->get_synthesized_plans();
		$total = count( $plans );
		$items = array_slice( $plans, $offset, $limit );

		return array(
			'items' => $items,
			'total' => $total,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_payouts( $limit, $offset ) {
		global $wpdb;

		$table = $wpdb->prefix . 'affiliate_wp_payouts';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} ORDER BY payout_id ASC LIMIT %d OFFSET %d",
				$limit,
				$offset
			)
		);

		$currency = get_woocommerce_currency();
		$items    = array();

		foreach ( $rows as $row ) {
			// AffiliateWP stores referral IDs as comma-separated string
			$referral_ids = array();
			if ( ! empty( $row->referrals ) ) {
				$referral_ids = array_map( 'intval', explode( ',', $row->referrals ) );
			}

			$items[] = array(
				'source_id'    => (int) $row->payout_id,
				'affiliate_id' => (int) $row->affiliate_id,
				'amount'       => (float) $row->amount,
				'currency'     => $currency,
				'method'       => isset( $row->payout_method ) ? $row->payout_method : 'manual',
				'status'       => isset( $row->status ) ? $row->status : 'paid',
				'referral_ids' => $referral_ids,
				'created_at'   => isset( $row->date ) ? $row->date : '',
			);
		}

		return array(
			'items' => $items,
			'total' => $total,
		);
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_hits( $limit, $offset ) {
		global $wpdb;

		$table = $wpdb->prefix . 'affiliate_wp_visits';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} ORDER BY visit_id ASC LIMIT %d OFFSET %d",
				$limit,
				$offset
			)
		);

		$items = array();
		foreach ( $rows as $row ) {
			$items[] = array(
				'source_id'    => (int) $row->visit_id,
				'affiliate_id' => (int) $row->affiliate_id,
				'url'          => isset( $row->url ) ? $row->url : '',
				'referrer'     => isset( $row->referrer ) ? $row->referrer : '',
				'ip_address'   => isset( $row->ip ) ? $row->ip : '',
				'user_agent'   => '',
				'created_at'   => isset( $row->date ) ? $row->date : '',
				'type'         => 'visit',
				'referral_id'  => isset( $row->referral_id ) ? (int) $row->referral_id : 0,
				'context'      => isset( $row->context ) ? $row->context : '',
			);
		}

		return array(
			'items' => $items,
			'total' => $total,
		);
	}

	/**
	 * Synthesize plan objects from distinct rate/rate_type combinations.
	 *
	 * @return array
	 */
	private function get_synthesized_plans() {
		global $wpdb;

		$table = $wpdb->prefix . 'affiliate_wp_affiliates';

		// Global default plan
		$default_rate      = (float) affiliate_wp()->settings->get( 'referral_rate', 20 );
		$default_rate_type = affiliate_wp()->settings->get( 'referral_rate_type', 'percentage' );

		$plans = array();
		$plan_id = 1;

		$plans[] = array(
			'source_id'        => 'default',
			'name'             => 'Default Plan',
			'commission_type'  => $default_rate_type,
			'commission_value' => $default_rate,
			'rules'            => array(),
			'status'           => 'active',
			'priority'         => 0,
			'is_default'       => true,
		);

		// Get distinct per-affiliate rate overrides
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$overrides = $wpdb->get_results(
			"SELECT DISTINCT rate, rate_type
			 FROM {$table}
			 WHERE rate IS NOT NULL AND rate != '' AND rate_type IS NOT NULL AND rate_type != ''
			 ORDER BY rate_type, rate"
		);

		foreach ( $overrides as $override ) {
			$rate      = (float) $override->rate;
			$rate_type = $override->rate_type;

			// Skip if identical to global default
			if ( abs( $rate - $default_rate ) < 0.001 && $rate_type === $default_rate_type ) {
				continue;
			}

			$plan_id++;
			$plans[] = array(
				'source_id'        => 'override_' . $plan_id,
				'name'             => ucfirst( $rate_type ) . ' ' . $rate . ( 'percentage' === $rate_type ? '%' : '' ),
				'commission_type'  => $rate_type,
				'commission_value' => $rate,
				'rules'            => array(),
				'status'           => 'active',
				'priority'         => $plan_id,
				'is_default'       => false,
			);
		}

		return $plans;
	}

	/**
	 * Count synthesized plans.
	 *
	 * @return int
	 */
	private function count_synthesized_plans() {
		return count( $this->get_synthesized_plans() );
	}
}
