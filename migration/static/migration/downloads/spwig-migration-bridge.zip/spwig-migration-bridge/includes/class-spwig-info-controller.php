<?php
/**
 * Info Controller
 *
 * GET /spwig/v1/info — returns plugin info, detected affiliate plugin,
 * record counts, and store metadata.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Spwig_Info_Controller extends Spwig_REST_Controller {

	/**
	 * REST resource name.
	 *
	 * @var string
	 */
	protected $rest_base = 'info';

	/**
	 * Register routes.
	 */
	public function register_routes() {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base,
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_info' ),
					'permission_callback' => array( $this, 'check_permissions' ),
				),
			)
		);
	}

	/**
	 * Handle GET /spwig/v1/info.
	 *
	 * @param WP_REST_Request $request The incoming request.
	 * @return WP_REST_Response
	 */
	public function get_info( $request ) {
		$detected = Spwig_Plugin_Detector::detect();
		$adapter  = $this->get_adapter();

		$counts = array(
			'affiliates' => 0,
			'referrals'  => 0,
			'plans'      => 0,
			'payouts'    => 0,
			'hits'       => 0,
		);

		if ( $adapter ) {
			$counts = $adapter->get_counts();
		}

		$data = array(
			'bridge_version'  => SPWIG_BRIDGE_VERSION,
			'detected_plugin' => $detected['plugin'],
			'plugin_name'     => $detected['name'],
			'plugin_version'  => $detected['version'],
			'wordpress'       => get_bloginfo( 'version' ),
			'woocommerce'     => defined( 'WC_VERSION' ) ? WC_VERSION : 'unknown',
			'php'             => PHP_VERSION,
			'store_url'       => home_url(),
			'store_name'      => get_bloginfo( 'name' ),
			'store_currency'  => function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD',
			'counts'          => $counts,
		);

		$response = new WP_REST_Response( $data, 200 );
		$response->header( 'X-Spwig-Bridge-Version', SPWIG_BRIDGE_VERSION );

		return $response;
	}
}
