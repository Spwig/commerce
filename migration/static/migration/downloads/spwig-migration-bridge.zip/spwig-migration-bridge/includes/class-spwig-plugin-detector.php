<?php
/**
 * Plugin Detector
 *
 * Detects which affiliate plugin is active on the WordPress site
 * and returns metadata about it.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Spwig_Plugin_Detector {

    /**
     * In-memory cache for the current request.
     *
     * @var array|null
     */
    private static $cached_result = null;

    /**
     * Detect which affiliate plugin is active.
     *
     * @return array {
     *     @type string $plugin    'affiliatewp' | 'afwc' | 'none'
     *     @type string $version   Plugin version string
     *     @type string $name      Human-readable plugin name
     * }
     */
    public static function detect() {
        if ( self::$cached_result !== null ) {
            return self::$cached_result;
        }

        $cached = get_transient( 'spwig_bridge_detected_plugin' );
        if ( $cached !== false ) {
            self::$cached_result = $cached;
            return $cached;
        }

        global $wpdb;
        $result = array(
            'plugin'  => 'none',
            'version' => '',
            'name'    => 'None detected',
        );

        // Check AffiliateWP first (larger market share)
        if ( class_exists( 'Affiliate_WP' ) || function_exists( 'affiliate_wp' ) ) {
            $table  = $wpdb->prefix . 'affiliate_wp_affiliates';
            $exists = self::table_exists( $table );

            if ( $exists ) {
                $result['plugin'] = 'affiliatewp';
                $result['name']   = 'AffiliateWP';

                if ( defined( 'AFFILIATEWP_VERSION' ) ) {
                    $result['version'] = AFFILIATEWP_VERSION;
                } elseif ( function_exists( 'affiliate_wp' ) ) {
                    $awp = affiliate_wp();
                    $result['version'] = isset( $awp->version ) ? $awp->version : 'unknown';
                }
            }
        }

        // Check Affiliate for WooCommerce (StoreApps)
        if ( $result['plugin'] === 'none' ) {
            $is_afwc = class_exists( 'Affiliate_For_WooCommerce' )
                || class_exists( 'AFWC_API' )
                || defined( 'STARTER_AFFILIATE_PLUGIN_FILE' );

            if ( $is_afwc ) {
                $table  = $wpdb->prefix . 'afwc_referrals';
                $exists = self::table_exists( $table );

                if ( $exists ) {
                    $result['plugin'] = 'afwc';
                    $result['name']   = 'Affiliate for WooCommerce';

                    if ( defined( 'SA_STARTER_AFFILIATE_PLUGIN_VERSION' ) ) {
                        $result['version'] = SA_STARTER_AFFILIATE_PLUGIN_VERSION;
                    }
                }
            }

            // Fallback: check if AFWC tables exist even without class detection
            // (handles cases where plugin loaded after our check)
            if ( $result['plugin'] === 'none' ) {
                $table  = $wpdb->prefix . 'afwc_referrals';
                $exists = self::table_exists( $table );

                if ( $exists ) {
                    // Verify there's actual affiliate data in user meta
                    $has_affiliates = $wpdb->get_var(
                        "SELECT COUNT(*) FROM {$wpdb->usermeta}
                         WHERE meta_key = 'afwc_is_affiliate' AND meta_value = 'yes'
                         LIMIT 1"
                    );

                    if ( $has_affiliates > 0 ) {
                        $result['plugin'] = 'afwc';
                        $result['name']   = 'Affiliate for WooCommerce';
                    }
                }
            }
        }

        set_transient( 'spwig_bridge_detected_plugin', $result, 5 * MINUTE_IN_SECONDS );
        self::$cached_result = $result;

        return $result;
    }

    /**
     * Get the appropriate adapter instance.
     *
     * @return Spwig_Affiliate_Adapter_Interface|null
     */
    public static function get_adapter() {
        $detected = self::detect();

        switch ( $detected['plugin'] ) {
            case 'affiliatewp':
                return new Spwig_AffiliateWP_Adapter();
            case 'afwc':
                return new Spwig_AFWC_Adapter();
            default:
                return null;
        }
    }

    /**
     * Clear the cached detection result.
     */
    public static function clear_cache() {
        self::$cached_result = null;
        delete_transient( 'spwig_bridge_detected_plugin' );
    }

    /**
     * Check if a database table exists.
     *
     * @param string $table Full table name.
     * @return bool
     */
    private static function table_exists( $table ) {
        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        $result = $wpdb->get_var(
            $wpdb->prepare(
                'SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = %s AND table_name = %s',
                DB_NAME,
                $table
            )
        );

        return (int) $result > 0;
    }
}
