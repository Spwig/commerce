# Spwig Test Gateway — maintainer notes

## What this is

A first-party **simulated** payment provider ("fake Stripe"). It exists so a
fresh Spwig install can exercise the complete embedded checkout flow without a
real PSP account, and so e2e tests get a deterministic gateway. **No real money
ever moves. Never enable on a live store.**

## Magic test cards

| Number                | Outcome |
|-----------------------|---------|
| `4242 4242 4242 4242` | Success |
| `4000 0000 0000 0002` | Declined (`card_declined`) |
| `4000 0000 0000 9995` | Declined (`insufficient_funds`) |
| `4000 0000 0000 3220` | 3DS challenge (fake modal in the handler), then success |
| `4000 0000 0000 0010` | AVS / postal-code check failure (`avs_failed`, retryable soft decline — mirrors Stripe's `address_zip_check: fail` test card) |
| anything else         | Generic decline (strict mode rejects non-Luhn numbers first as `incorrect_number`) |

Expiry must be in the future; CVC must be 3–4 digits.

## Magic amounts

| Trigger | Outcome |
|---------|---------|
| Order total ends in `.19` | Simulated **webhook-style delayed capture**: confirm returns `status: processing`; `retrieve_payment_intent` flips the intent to `succeeded` once ~3 s (`PROCESSING_DELAY_SECONDS`) have elapsed. The handler polls `GET /api/payments/intents/<uuid>/`, whose `verify_and_sync_payment_status` call settles the order through the platform's webhook-success path (`WebhookService.handle_payment_intent_succeeded`) — the only trigger that exercises that path. |

## Strict mode (v1.1.0, default ON)

The checkout-intent path (`create_payment_intent_for_checkout`) validates the
request the way a real PSP would, and fails intent creation with
`success=False` plus an aggregated message naming **every** missing/invalid
field and which real providers require it (Stripe as baseline, semantics per
docs.stripe.com/api). The point is to surface missing-field bugs in checkout
flows that a permissive fake gateway would let through.

Checks at intent creation:

| Field | Check | Real-PSP anchor |
|-------|-------|-----------------|
| `customer_email` | present + RFC-plausible | Stripe `receipt_email`/`customer`; PayPal `payer.email_address`; Square `buyer_email_address` |
| `customer_name` | non-empty | Stripe `billing_details[name]`; PayPal `payer.name` |
| `customer_country` | present, ISO-2, in supported set | Stripe `country_unsupported`; PayPal `address.country_code`; AVS baseline |
| `amount` | > 0 (always), ≥ per-currency minimum (strict) | Stripe minimum charge amounts (USD 0.50, EUR 0.50, GBP 0.30, SGD 0.50, AUD 0.50, JPY 50, …) |
| `amount` (zero-decimal) | whole units for JPY/KRW/VND/CLP — a fractional JPY amount is a classic minor-unit mis-scaling bug and is rejected loudly | Stripe zero-decimal currencies |
| `currency` | in supported set (always, not just strict) | — |
| `return_url` / `cancel_url` | present + http(s) | Stripe `return_url`/`success_url`/`cancel_url`; PayPal `application_context.return_url` |
| `payment_method_types` | `None` OK; else non-empty list containing at least one of `card`/`credit_card`/`debit_card` | Stripe `payment_method_types` |
| `metadata` | dict; ≤ 50 keys; keys ≤ 40 chars; values ≤ 500 chars | Stripe metadata limits |

Checks at confirm (soft declines — intent stays retryable):

- `cardholder_name` non-empty (`cardholder_name_required`).
- Luhn checksum on the card number (`incorrect_number`). All documented
  magic cards are Luhn-valid.

**Opting out:** `{"strict_mode": false}` in the provider account credentials
(or provider config) restores the 1.0.0 permissive behaviour. Permissive mode
exists **only** so the platform's own unit tests can drive minimal payloads —
never disable strict mode to "fix" a checkout flow; the rejection means the
flow has a real gap.

## Confirm mechanism (how the flow actually works)

1. `create_payment_intent_for_checkout` returns an embedded-mode response
   (`client_secret` non-empty, `checkout_url` empty) with a `test_pi_<hex>`
   provider intent id. `raw_response` carries `id` + `currency` so the
   platform's generic `handler_config` branch
   (`payment_providers/api_serializers.py::get_handler_config`) builds
   `{intent_id, currency}` for slugs it doesn't special-case.
2. The platform serves `checkout-handler.js` via
   `/components/payments/test_gateway/current/checkout-handler.js`
   (`ComponentStaticFileView`); the handler renders a local, CSP-safe card
   form (its stylesheet is fetched from the same component-static route).
3. The handler POSTs `/api/payments/intents/<platform-uuid>/confirm/` with
   `{"payment_method_data": {"card": {...}}}`. `PaymentIntentConfirmView` →
   `PaymentOrchestrationService.confirm_payment_intent` →
   `TestGatewayProvider.confirm_payment_intent(provider_intent_id, data)`.
4. The card number decides the outcome. For `...3220` the first confirm
   returns `success=True, requires_action=True,
   action.type='test_3ds_challenge'` (success **must** be True here — the
   orchestrator marks the intent failed on any `success=False`); the handler
   shows a fake authentication modal, then re-confirms with
   `three_ds_completed: true` (or `three_ds_failed: true` to test failure).
5. On `status='succeeded'` the orchestrator runs `mark_succeeded` +
   `handle_payment_success`; the handler calls `onSuccess(order_number)` and
   the customer lands on the confirmation page.

## State model (deliberately ephemeral)

Intent/charge/authorization state lives in a module-level dict, mirrored into
the Django cache (`spwig_test_gateway:*`, 24h TTL) when one is configured so
dev server + Celery agree when they share Redis. It does **not** survive
restarts; the platform's `PaymentIntent` row remains the source of truth.
Consequences:

- `retrieve_payment_intent` for an unknown id reports `created` (never
  `failed`) so `verify_and_sync_payment_status` cannot kill a live checkout
  after a restart.
- Refunding a charge from before a restart returns `charge_not_found`.
- `refund()` accepts either a `test_ch_` charge id or a `test_pi_` intent id
  (resolved to its charge) and enforces the refundable balance.

## Safety tagging

Every `raw_response`, `test_connection` payload, and error response includes
`"test_gateway": true`. Descriptions, setup instructions, the checkout form
banner, and the fake 3DS dialog all state that payments are simulated.

## Production activation warning

The platform does not currently have a generic "sandbox provider" flag in the
provider context, so activation on a production store cannot be blocked from
inside a component. If the platform ever grows such a flag, this component
should declare it; until then the platform-side admin UI is the right place to
warn when `test_gateway` is enabled while `DEBUG=False`. (Component-only
delivery — no platform code was modified.)

## Checkout gaps strict mode has already caught

- **Digital-only orders sent an empty `customer_name`** (2026-07-22). With no
  shipping address and billing defaulting to same-as-shipping, the platform
  orchestrator passed `customer_name=""`. Fixed platform-side by falling back
  to the account holder's full name. Residual gap: a **guest** digital
  checkout (or an account with no name) still has no name anywhere in the
  flow — the checkout UI collects no name for digital-only carts, so strict
  mode fails intent creation with `customer_name_required`. A real PSP
  integration would hit the equivalent problem; the proper fix is collecting
  a billing name in the digital checkout flow.

## Known contract quirks found while building this

- `get_handler_config` special-cases provider slugs; unknown slugs get only
  `{intent_id, currency}`. The amount is therefore also mirrored into
  `handler_config` in the provider response for future use, but the handler
  does not rely on it.
- Confirm responses with `success=False` mark the intent **failed
  (terminal)** — retries require a new intent. The handler therefore calls
  `onError(...)` after declines so the platform's retry path takes over.
- The example SDK provider returns `success=False` for `requires_action`
  confirms; against the real orchestrator that would mark the intent failed.
  This component intentionally deviates (returns `success=True`).
