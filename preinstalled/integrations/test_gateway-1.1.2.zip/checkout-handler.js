/* Copyright (c) 2025-2026 Spwig. Licensed under AGPL-3.0. */

/**
 * Spwig Test Gateway Checkout Handler
 *
 * Dynamically loaded plugin for the SIMULATED Spwig Test Gateway.
 * Implements the standard PaymentHandlers interface for the Spwig platform.
 *
 * Renders its own plain-DOM card form (no external SDK, no network
 * dependency, CSP-safe: no inline styles or inline event handlers) and
 * confirms the payment through the platform's own confirm endpoint:
 *
 *     POST /api/payments/intents/<intent_id>/confirm/
 *     { "payment_method_data": { "card": {...}, ... } }
 *
 * Magic test cards:
 *     4242 4242 4242 4242  -> success
 *     4000 0000 0000 0002  -> declined
 *     4000 0000 0000 9995  -> insufficient funds
 *     4000 0000 0000 3220  -> 3DS challenge (fake modal), then success
 *     4000 0000 0000 0010  -> AVS/postal-code failure (retryable decline)
 *     anything else        -> generic decline
 *
 * Magic amounts:
 *     order totals ending in .19 -> confirm returns 'processing'; this
 *     handler polls the platform intent endpoint until the simulated
 *     webhook-style delay (~3s) completes and the payment succeeds.
 *
 * NO REAL MONEY EVER MOVES. Never enable this gateway on a live store.
 *
 * @version 1.1.0
 * @author Spwig
 */
(function() {
    'use strict';

    window.PaymentHandlers = window.PaymentHandlers || {};

    var STYLES_HREF = '/components/payments/test_gateway/current/checkout-styles.css';

    var TEST_CARDS = [
        { number: '4242 4242 4242 4242', label: 'Success' },
        { number: '4000 0000 0000 0002', label: 'Declined' },
        { number: '4000 0000 0000 9995', label: 'Insufficient funds' },
        { number: '4000 0000 0000 3220', label: '3D Secure challenge' },
        { number: '4000 0000 0000 0010', label: 'AVS / postal-code fail' }
    ];

    function getCookie(name) {
        var value = null;
        if (document.cookie && document.cookie !== '') {
            document.cookie.split(';').forEach(function(cookie) {
                var trimmed = cookie.trim();
                if (trimmed.substring(0, name.length + 1) === name + '=') {
                    value = decodeURIComponent(trimmed.substring(name.length + 1));
                }
            });
        }
        return value;
    }

    function getCsrfToken() {
        // Spwig sets CSRF_COOKIE_HTTPONLY, so the cookie is unreadable from
        // JS on standard installs — the base template's meta tag is the
        // canonical source; cookie kept as a fallback for embedded contexts.
        var meta = document.querySelector('meta[name="csrf-token"]');
        if (meta && meta.content) return meta.content;
        var input = document.querySelector('[name=csrfmiddlewaretoken]');
        if (input && input.value) return input.value;
        return getCookie('csrftoken') || '';
    }

    function el(tag, className, text) {
        var node = document.createElement(tag);
        if (className) { node.className = className; }
        if (text) { node.textContent = text; }
        return node;
    }

    window.PaymentHandlers.test_gateway = {
        _root: null,
        _modal: null,
        _intentData: null,

        /**
         * Initialize the test gateway embedded checkout form.
         *
         * @param {object} intentData - Payment intent response from the API
         *   (intent_id, order_number, handler_config: {intent_id, currency})
         * @param {HTMLElement} container - Container element for the form
         * @param {function} onSuccess - Called with orderNumber on success
         * @param {function} onError - Called with an error message on failure
         */
        async initialize(intentData, container, onSuccess, onError) {
            try {
                this._intentData = intentData;
                this._ensureStyles();

                if (!intentData || !intentData.intent_id) {
                    throw new Error('Missing payment intent data for the test gateway');
                }

                container.textContent = '';

                var root = el('div', 'tg-container');
                this._root = root;

                // Unmissable simulation banner
                var banner = el('div', 'tg-banner');
                banner.appendChild(el('strong', null, 'TEST GATEWAY'));
                banner.appendChild(el('span', null,
                    ' This is a simulated payment. No real card will be ' +
                    'charged and no money will move.'));
                root.appendChild(banner);

                // Card form
                var form = el('form', 'tg-form');
                form.setAttribute('novalidate', 'novalidate');

                form.appendChild(this._buildField('tg-card-name', 'Name on card', {
                    type: 'text', autocomplete: 'cc-name', placeholder: 'Test Customer'
                }));
                form.appendChild(this._buildField('tg-card-number', 'Card number', {
                    type: 'text', inputmode: 'numeric', autocomplete: 'cc-number',
                    placeholder: '4242 4242 4242 4242'
                }));

                var row = el('div', 'tg-row');
                row.appendChild(this._buildField('tg-card-expiry', 'Expiry (MM/YY)', {
                    type: 'text', inputmode: 'numeric', autocomplete: 'cc-exp',
                    placeholder: '12/34'
                }));
                row.appendChild(this._buildField('tg-card-cvc', 'CVC', {
                    type: 'text', inputmode: 'numeric', autocomplete: 'cc-csc',
                    placeholder: '123', maxlength: '4'
                }));
                form.appendChild(row);

                var error = el('div', 'tg-error');
                error.id = 'tg-error-message';
                error.hidden = true;
                form.appendChild(error);

                var submit = el('button', 'btn btn-primary tg-submit', 'Complete Test Payment');
                submit.type = 'submit';
                submit.id = 'tg-submit-btn';
                form.appendChild(submit);

                root.appendChild(form);

                // Magic card quick-fill helper
                var helper = el('div', 'tg-cards-helper');
                helper.appendChild(el('div', 'tg-cards-helper-title', 'Magic test cards (click to fill):'));
                var list = el('div', 'tg-cards-list');
                TEST_CARDS.forEach(function(card) {
                    var chip = el('button', 'tg-card-chip');
                    chip.type = 'button';
                    chip.dataset.cardNumber = card.number;
                    chip.appendChild(el('span', 'tg-card-chip-number', card.number));
                    chip.appendChild(el('span', 'tg-card-chip-label', card.label));
                    list.appendChild(chip);
                });
                helper.appendChild(list);
                helper.appendChild(el('div', 'tg-cards-helper-note',
                    'Tip: an order total ending in .19 simulates a delayed ' +
                    '(webhook-style) capture — the payment shows ' +
                    '"processing" for a few seconds before succeeding.'));
                root.appendChild(helper);

                container.appendChild(root);

                // Events (CSP-safe: addEventListener only)
                var self = this;
                list.addEventListener('click', function(e) {
                    var chip = e.target.closest('.tg-card-chip');
                    if (!chip) { return; }
                    root.querySelector('#tg-card-number').value = chip.dataset.cardNumber;
                    var nameField = root.querySelector('#tg-card-name');
                    if (!nameField.value) { nameField.value = 'Test Customer'; }
                    var expiryField = root.querySelector('#tg-card-expiry');
                    if (!expiryField.value) { expiryField.value = '12/34'; }
                    var cvcField = root.querySelector('#tg-card-cvc');
                    if (!cvcField.value) { cvcField.value = '123'; }
                });

                form.addEventListener('submit', function(e) {
                    e.preventDefault();
                    self._submitPayment(intentData, onSuccess, onError);
                });

                console.log('[TestGateway] Simulated card form ready');
            } catch (err) {
                console.error('[TestGateway] Initialization error:', err);
                onError(err.message || 'Failed to initialize the test payment form.');
            }
        },

        /** Inject the component stylesheet once. */
        _ensureStyles() {
            if (!document.querySelector('link[href="' + STYLES_HREF + '"]')) {
                var link = document.createElement('link');
                link.rel = 'stylesheet';
                link.href = STYLES_HREF;
                document.head.appendChild(link);
            }
        },

        _buildField(id, labelText, attrs) {
            var wrap = el('div', 'tg-field');
            var label = el('label', 'tg-label', labelText);
            label.setAttribute('for', id);
            var input = el('input', 'tg-input');
            input.id = id;
            Object.keys(attrs).forEach(function(key) {
                input.setAttribute(key, attrs[key]);
            });
            wrap.appendChild(label);
            wrap.appendChild(input);
            return wrap;
        },

        _cardholderName() {
            var field = this._root && this._root.querySelector('#tg-card-name');
            return field ? field.value.trim() : '';
        },

        _readCard() {
            var root = this._root;
            var expiryRaw = root.querySelector('#tg-card-expiry').value.trim();
            var parts = expiryRaw.split(/[\/\s]+/);
            return {
                number: root.querySelector('#tg-card-number').value.trim(),
                exp_month: parseInt(parts[0], 10) || 0,
                exp_year: parseInt(parts[1], 10) || 0,
                cvc: root.querySelector('#tg-card-cvc').value.trim()
            };
        },

        _showError(message) {
            var error = this._root && this._root.querySelector('#tg-error-message');
            if (error) {
                error.classList.remove('tg-error--info');
                error.textContent = message;
                error.hidden = false;
            }
        },

        /** Reuse the message area for non-error status (processing). */
        _showInfo(message) {
            var error = this._root && this._root.querySelector('#tg-error-message');
            if (error) {
                error.classList.add('tg-error--info');
                error.textContent = message;
                error.hidden = false;
            }
        },

        _setBusy(busy) {
            var submit = this._root && this._root.querySelector('#tg-submit-btn');
            if (submit) {
                submit.disabled = busy;
                submit.textContent = busy ? 'Processing…' : 'Complete Test Payment';
            }
        },

        async _confirm(intentData, paymentMethodData) {
            var response = await fetch('/api/payments/intents/' + intentData.intent_id + '/confirm/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCsrfToken()
                },
                credentials: 'same-origin',
                body: JSON.stringify({ payment_method_data: paymentMethodData })
            });
            var data = null;
            try {
                data = await response.json();
            } catch (e) {
                data = {};
            }
            data._httpOk = response.ok;
            return data;
        },

        async _submitPayment(intentData, onSuccess, onError) {
            var error = this._root.querySelector('#tg-error-message');
            error.hidden = true;
            this._setBusy(true);

            var card = this._readCard();

            try {
                var result = await this._confirm(intentData, {
                    card: card,
                    cardholder_name: this._root.querySelector('#tg-card-name').value.trim()
                });

                if (result._httpOk && result.success && result.status === 'succeeded') {
                    console.log('[TestGateway] Simulated payment succeeded');
                    onSuccess(intentData.order_number);
                    return;
                }

                if (result._httpOk && result.requires_action &&
                        result.action && result.action.type === 'test_3ds_challenge') {
                    console.log('[TestGateway] Simulated 3DS challenge required');
                    this._show3dsModal(intentData, card, onSuccess, onError);
                    return;
                }

                if (result._httpOk && result.success && result.status === 'processing') {
                    // Magic .19 amount: simulated webhook-style delay.
                    console.log('[TestGateway] Payment processing (simulated webhook delay)');
                    this._pollProcessing(intentData, onSuccess, onError);
                    return;
                }

                var message = result.message ||
                    (result.error && result.error.message) ||
                    'Payment failed. Please try again.';

                if (result._httpOk && result.status === 'requires_payment_method') {
                    // Soft decline: the intent stays retryable — show the
                    // reason inline and let the customer fix the card and
                    // try again. Never tear the form down for a decline.
                    console.warn('[TestGateway] Simulated decline (retryable):', message);
                    this._showError(message);
                    this._setBusy(false);
                    return;
                }

                console.warn('[TestGateway] Payment failed:', message);
                this._showError(message);
                this._setBusy(false);
                onError(message);
            } catch (err) {
                console.error('[TestGateway] Confirmation error:', err);
                this._showError('Payment failed. Please try again.');
                this._setBusy(false);
                onError(err.message || 'Payment confirmation failed. Please try again.');
            }
        },

        /**
         * Poll the platform intent endpoint while a simulated
         * webhook-style capture (.19 amount) is processing. The GET
         * triggers the platform's verify_and_sync path, which asks this
         * provider for the intent status and settles the order once the
         * simulated delay elapses.
         */
        _pollProcessing(intentData, onSuccess, onError) {
            var self = this;
            var attempts = 0;
            var maxAttempts = 20;
            this._setBusy(true);
            this._showInfo('Payment accepted — processing. Simulating the ' +
                'gateway’s webhook delay…');

            async function poll() {
                attempts++;
                try {
                    var response = await fetch(
                        '/api/payments/intents/' + intentData.intent_id + '/',
                        { credentials: 'same-origin' }
                    );
                    var data = await response.json();
                    if (data.status === 'succeeded') {
                        console.log('[TestGateway] Delayed capture settled — payment succeeded');
                        onSuccess(data.order_number || intentData.order_number);
                        return;
                    }
                    if (data.status === 'failed' || data.status === 'canceled') {
                        var message = 'Payment was not completed. Please try again.';
                        self._showError(message);
                        self._setBusy(false);
                        onError(message);
                        return;
                    }
                } catch (err) {
                    console.error('[TestGateway] Processing poll error:', err);
                }
                if (attempts < maxAttempts) {
                    setTimeout(poll, 1000);
                } else {
                    self._showError('Payment is still processing. Refresh the page to check the latest status.');
                    self._setBusy(false);
                }
            }

            setTimeout(poll, 1000);
        },

        /**
         * Fake 3D Secure modal. Appended to document.body — overlays must
         * never live inside <header> or the checkout container (stacking
         * context / containing-block traps; see platform docs).
         */
        _show3dsModal(intentData, card, onSuccess, onError) {
            this._remove3dsModal();

            var overlay = el('div', 'tg-3ds-overlay');
            var dialog = el('div', 'tg-3ds-dialog');
            dialog.setAttribute('role', 'dialog');
            dialog.setAttribute('aria-modal', 'true');
            dialog.setAttribute('aria-labelledby', 'tg-3ds-title');

            var title = el('h3', 'tg-3ds-title', 'Simulated 3D Secure');
            title.id = 'tg-3ds-title';
            dialog.appendChild(title);
            dialog.appendChild(el('p', 'tg-3ds-text',
                'Your bank would normally verify this payment now. This is ' +
                'a simulation from the Spwig Test Gateway — no real ' +
                'authentication is happening.'));

            var actions = el('div', 'tg-3ds-actions');
            var complete = el('button', 'btn btn-primary tg-3ds-complete', 'Complete authentication');
            complete.type = 'button';
            var fail = el('button', 'btn tg-3ds-fail', 'Fail authentication');
            fail.type = 'button';
            actions.appendChild(complete);
            actions.appendChild(fail);
            dialog.appendChild(actions);
            overlay.appendChild(dialog);
            document.body.appendChild(overlay);
            this._modal = overlay;

            if (window.SpwigPortal && typeof window.SpwigPortal.lockScroll === 'function') {
                window.SpwigPortal.lockScroll();
            }

            var self = this;

            complete.addEventListener('click', async function() {
                complete.disabled = true;
                fail.disabled = true;
                try {
                    var result = await self._confirm(intentData, {
                        card: card,
                        cardholder_name: self._cardholderName(),
                        three_ds_completed: true
                    });
                    self._remove3dsModal();
                    if (result._httpOk && result.success && result.status === 'succeeded') {
                        console.log('[TestGateway] Simulated 3DS completed — payment succeeded');
                        onSuccess(intentData.order_number);
                    } else if (result._httpOk && result.success && result.status === 'processing') {
                        console.log('[TestGateway] 3DS completed — delayed capture processing');
                        self._pollProcessing(intentData, onSuccess, onError);
                    } else {
                        var message = result.message || 'Payment failed after authentication.';
                        self._showError(message);
                        self._setBusy(false);
                        if (!(result._httpOk && result.status === 'requires_payment_method')) {
                            onError(message);
                        }
                    }
                } catch (err) {
                    self._remove3dsModal();
                    self._showError('Payment failed. Please try again.');
                    self._setBusy(false);
                    onError(err.message || 'Payment confirmation failed.');
                }
            });

            fail.addEventListener('click', async function() {
                complete.disabled = true;
                fail.disabled = true;
                try {
                    var result = await self._confirm(intentData, {
                        card: card,
                        cardholder_name: self._cardholderName(),
                        three_ds_failed: true
                    });
                    var message = (result && result.message) ||
                        '3D Secure authentication failed. (Simulated failure.)';
                    self._remove3dsModal();
                    self._showError(message);
                    self._setBusy(false);
                    if (!(result && result._httpOk && result.status === 'requires_payment_method')) {
                        onError(message);
                    }
                } catch (err) {
                    self._remove3dsModal();
                    self._showError('Authentication failed.');
                    self._setBusy(false);
                    onError('Authentication failed.');
                }
            });
        },

        _remove3dsModal() {
            if (this._modal && this._modal.parentNode) {
                this._modal.parentNode.removeChild(this._modal);
            }
            this._modal = null;
            if (window.SpwigPortal && typeof window.SpwigPortal.unlockScroll === 'function') {
                window.SpwigPortal.unlockScroll();
            }
        },

        /**
         * Cleanup handler resources.
         * Called when navigating away or switching payment methods.
         */
        cleanup() {
            console.log('[TestGateway] Cleaning up handler resources');
            this._remove3dsModal();
            if (this._root && this._root.parentNode) {
                this._root.parentNode.removeChild(this._root);
            }
            this._root = null;
            this._intentData = null;
        }
    };

    console.log('[TestGateway] Handler registered successfully — SIMULATED payments only');
})();
