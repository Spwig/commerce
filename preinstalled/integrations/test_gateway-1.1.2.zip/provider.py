"""
Spwig Test Gateway
==================

A first-party SIMULATED payment provider for the Spwig platform.

This is a "fake Stripe": it lets a fresh Spwig install exercise the full
embedded checkout flow (payment intent -> card form -> confirm -> order
paid) without signing up with a real payment service provider, and gives
end-to-end tests a fully deterministic gateway.

    *** NO REAL MONEY EVER MOVES THROUGH THIS PROVIDER. ***
    *** NEVER ENABLE IT ON A LIVE STORE.               ***

Design notes
------------
- 100% local. No external HTTP calls, no SDKs, no network dependency.
- Outcomes are decided by magic test card numbers (documented in
  setup_instructions.html):
      4242 4242 4242 4242  -> success
      4000 0000 0000 0002  -> declined
      4000 0000 0000 9995  -> insufficient funds
      4000 0000 0000 3220  -> 3DS challenge, then success
      4000 0000 0000 0010  -> AVS / postal-code check failure (soft decline)
      anything else        -> generic decline
- Order totals ending in .19 simulate a webhook-style delayed capture:
  confirm returns status 'processing'; the intent flips to 'succeeded' on
  the first retrieve after ~3 seconds — exercising the platform's
  status-polling / delayed-webhook path.
- STRICT MODE (default ON, v1.1.0): the checkout-intent path validates the
  request the way a real PSP would — required customer fields, per-currency
  minimum amounts, zero-decimal currency correctness, http(s) return URLs —
  with error messages citing which real providers (Stripe / PayPal / Square,
  semantics per docs.stripe.com/api) require each field. Missing-field bugs
  in checkout flows surface here instead of silently passing. Opt out with
  ``{"strict_mode": false}`` — permissive mode exists ONLY so the
  platform's own unit tests can drive minimal payloads.
- Intent/charge state is kept in a small in-process store, mirrored to
  the Django cache when one is configured (so the dev server and Celery
  workers agree when they share Redis). State is deliberately ephemeral;
  the platform's own PaymentIntent record is the source of truth.
- Every raw_response carries ``"test_gateway": True`` so downstream
  systems can always recognise simulated traffic.
"""

import logging
import re
import time
import uuid
from datetime import datetime, timedelta, timezone as dt_timezone
from decimal import Decimal, InvalidOperation
from typing import Any, Dict, List, Optional

from payment_providers.providers.base import PaymentProviderBase

logger = logging.getLogger(__name__)


TEST_GATEWAY_NOTICE = (
    "TEST GATEWAY — not a real payment provider. All payments are "
    "simulated; no money moves. Never enable on a live store."
)

# Magic test cards (normalised, digits only)
CARD_SUCCESS = "4242424242424242"
CARD_DECLINED = "4000000000000002"
CARD_INSUFFICIENT_FUNDS = "4000000000009995"
CARD_3DS_CHALLENGE = "4000000000003220"
CARD_AVS_FAIL = "4000000000000010"  # Stripe's address/ZIP-check-fail test card

# Maximum artificial latency merchants may configure (safety cap)
MAX_LATENCY_MS = 10_000

# Simulated webhook-style delay for order totals ending in .19: confirm
# returns 'processing'; retrieve flips to 'succeeded' once this many
# seconds have elapsed. (Module-level so tests can patch it.)
PROCESSING_DELAY_SECONDS = 3.0

# Currencies charged in whole units (Stripe "zero-decimal" semantics,
# docs.stripe.com/currencies#zero-decimal) — a fractional amount in one of
# these is a classic minor-unit mis-scaling bug and is rejected loudly.
ZERO_DECIMAL_CURRENCIES = {"JPY", "KRW", "VND", "CLP"}

# Per-currency minimum charge amounts, mirroring Stripe's published
# minimums (docs.stripe.com/currencies#minimum-and-maximum-charge-amounts).
# Currencies not listed have no enforced minimum beyond amount > 0.
MINIMUM_CHARGE_AMOUNTS = {
    "USD": Decimal("0.50"),
    "AED": Decimal("2.00"),
    "AUD": Decimal("0.50"),
    "BGN": Decimal("1.00"),
    "BRL": Decimal("0.50"),
    "CAD": Decimal("0.50"),
    "CHF": Decimal("0.50"),
    "CZK": Decimal("15.00"),
    "DKK": Decimal("2.50"),
    "EUR": Decimal("0.50"),
    "GBP": Decimal("0.30"),
    "HKD": Decimal("4.00"),
    "HUF": Decimal("175.00"),
    "INR": Decimal("0.50"),
    "JPY": Decimal("50"),
    "MXN": Decimal("10"),
    "MYR": Decimal("2.00"),
    "NOK": Decimal("3.00"),
    "NZD": Decimal("0.50"),
    "PLN": Decimal("2.00"),
    "RON": Decimal("2.00"),
    "SEK": Decimal("3.00"),
    "SGD": Decimal("0.50"),
    "THB": Decimal("10.00"),
}

# RFC-plausible email check (not full RFC 5322 — the same pragmatic level
# real PSPs apply before rejecting receipt_email / shopperEmail).
EMAIL_RE = re.compile(
    r"^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~\-]+@[A-Za-z0-9\-]+(\.[A-Za-z0-9\-]+)+$"
)

# Payment method type slugs this gateway can serve when the platform
# passes an explicit payment_method_types list.
ACCEPTED_PAYMENT_METHOD_TYPES = {"card", "credit_card", "debit_card"}

# How long simulated state is kept in the Django cache (seconds)
STATE_TTL_SECONDS = 60 * 60 * 24  # 24 hours


# ---------------------------------------------------------------------------
# Ephemeral state store
# ---------------------------------------------------------------------------
# In-process dict, mirrored to the Django cache when available. Unit tests
# run without Django configured — the cache mirror silently no-ops there.

_MEMORY_STORE: Dict[str, Dict[str, Any]] = {}
_CACHE_PREFIX = "spwig_test_gateway:"


def _state_get(key: str) -> Optional[Dict[str, Any]]:
    """Read simulated object state (memory first, then Django cache)."""
    value = _MEMORY_STORE.get(key)
    if value is not None:
        return value
    try:
        from django.core.cache import cache

        cached = cache.get(_CACHE_PREFIX + key)
        if cached is not None:
            _MEMORY_STORE[key] = cached
            return cached
    except Exception:  # pragma: no cover - no Django / no cache configured
        pass
    return None


def _state_set(key: str, value: Dict[str, Any]) -> None:
    """Write simulated object state (memory + Django cache mirror)."""
    _MEMORY_STORE[key] = value
    try:
        from django.core.cache import cache

        cache.set(_CACHE_PREFIX + key, value, STATE_TTL_SECONDS)
    except Exception:  # pragma: no cover - no Django / no cache configured
        pass


def _reset_state_store() -> None:
    """Clear the in-memory store. Intended for tests only."""
    _MEMORY_STORE.clear()


# ---------------------------------------------------------------------------
# Card validation / outcome evaluation
# ---------------------------------------------------------------------------

def _normalise_card_number(number: Any) -> str:
    """Strip spaces and dashes from a card number."""
    if not isinstance(number, str):
        number = str(number or "")
    return re.sub(r"[\s\-]", "", number)


def _luhn_valid(number: str) -> bool:
    """Luhn checksum, as every real PSP applies before routing a card."""
    if not number.isdigit():
        return False
    total = 0
    for index, digit_char in enumerate(reversed(number)):
        digit = int(digit_char)
        if index % 2 == 1:
            digit *= 2
            if digit > 9:
                digit -= 9
        total += digit
    return total % 10 == 0


def _is_delayed_success_amount(amount: Any) -> bool:
    """True when the amount ends in .19 — the delayed-capture magic trigger."""
    try:
        cents = (Decimal(str(amount)) * 100) % 100
    except (InvalidOperation, TypeError, ValueError):
        return False
    return cents == 19


def _plausible_email(value: Any) -> bool:
    return isinstance(value, str) and bool(EMAIL_RE.fullmatch(value.strip()))


def _plausible_phone(value: Any) -> bool:
    """
    Lenient, international-friendly phone check: optional leading +,
    digits with common separators (spaces, hyphens, dots, slashes,
    parentheses), at least 5 digits. Mirrors what real PSPs accept for
    shopperTelephoneNumber / billing_details[phone].
    """
    if not isinstance(value, str):
        return False
    phone = value.strip()
    if not phone or not re.fullmatch(r"\+?[0-9()\-./\s]+", phone):
        return False
    return len(re.sub(r"\D", "", phone)) >= 5


def _valid_http_url(value: Any) -> bool:
    if not isinstance(value, str) or not value.strip():
        return False
    try:
        from urllib.parse import urlparse

        parsed = urlparse(value.strip())
    except ValueError:
        return False
    return parsed.scheme in ("http", "https") and bool(parsed.netloc)


def _validate_card_details(card: Dict[str, Any]) -> Optional[Dict[str, str]]:
    """
    Validate structural card details (number format, expiry, CVC).

    Returns None when valid, otherwise an error dict with 'code' and
    'message'.
    """
    number = _normalise_card_number(card.get("number", ""))
    if not number.isdigit() or not (12 <= len(number) <= 19):
        return {
            "code": "invalid_number",
            "message": "The card number is not a valid card number.",
        }

    # Expiry
    try:
        exp_month = int(card.get("exp_month", 0))
        exp_year = int(card.get("exp_year", 0))
    except (TypeError, ValueError):
        return {
            "code": "invalid_expiry",
            "message": "The card expiry date is invalid.",
        }

    if exp_year < 100:
        exp_year += 2000

    if not (1 <= exp_month <= 12):
        return {
            "code": "invalid_expiry_month",
            "message": "The card expiry month is invalid.",
        }

    now = datetime.now(dt_timezone.utc)
    if (exp_year, exp_month) < (now.year, now.month):
        return {
            "code": "expired_card",
            "message": "The card has expired. Use any future expiry date.",
        }

    # CVC: 3-4 digits
    cvc = str(card.get("cvc", "") or "")
    if not re.fullmatch(r"\d{3,4}", cvc):
        return {
            "code": "invalid_cvc",
            "message": "The card security code must be 3 or 4 digits.",
        }

    return None


def _evaluate_card_outcome(number: str) -> Dict[str, Any]:
    """
    Map a (normalised) card number to its simulated outcome.

    Returns a dict with:
        outcome: 'success' | 'declined' | 'requires_3ds'
        code/message: populated for declines
    """
    if number == CARD_SUCCESS:
        return {"outcome": "success"}
    if number == CARD_3DS_CHALLENGE:
        return {"outcome": "requires_3ds"}
    if number == CARD_DECLINED:
        return {
            "outcome": "declined",
            "code": "card_declined",
            "message": "Your card was declined. (Simulated decline.)",
        }
    if number == CARD_INSUFFICIENT_FUNDS:
        return {
            "outcome": "declined",
            "code": "insufficient_funds",
            "message": "Your card has insufficient funds. (Simulated decline.)",
        }
    if number == CARD_AVS_FAIL:
        return {
            "outcome": "declined",
            "code": "avs_failed",
            "message": (
                "The address verification (AVS) check failed: the postal "
                "code did not match the card. Check the billing postal "
                "code and try again. (Simulated AVS failure — mirrors "
                "Stripe test card 4000 0000 0000 0010, "
                "address_zip_check: fail.)"
            ),
        }
    return {
        "outcome": "declined",
        "code": "card_declined",
        "message": (
            "Your card was declined. The Spwig Test Gateway only accepts "
            "the documented test card numbers (e.g. 4242 4242 4242 4242)."
        ),
    }


class TestGatewayProvider(PaymentProviderBase):
    """
    Spwig Test Gateway — deterministic, fully local simulated payments.

    Everything succeeds or fails according to magic card numbers; state
    lives in an ephemeral in-process/cache store. See module docstring.
    """

    provider_key = "test_gateway"
    provider_name = "Spwig Test Gateway"

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def capabilities(self) -> Dict[str, bool]:
        return {
            "charge": True,
            "authorize": True,
            "capture": True,
            "void": True,
            "refund": True,
            "partial_refund": True,
            "recurring": False,
            "save_payment_method": False,
            "hosted_checkout": False,
            "integrated_checkout": True,
            "webhooks": False,
            "multi_currency": True,
        }

    @property
    def credential_schema(self) -> Dict[str, Any]:
        # No real credentials exist — settings are strict-mode and optional
        # artificial latency for testing spinners/timeouts.
        return {
            "strict_mode": {
                "type": "boolean",
                "label": "Strict mode (validate like a real PSP)",
                "help_text": (
                    "Validate checkout requests the way a real payment "
                    "provider would (required customer fields, per-currency "
                    "minimum amounts, zero-decimal currency correctness). "
                    "Leave ON — it surfaces missing-field bugs in checkout "
                    "flows. Turn off ONLY for unit-testing the platform "
                    "itself with minimal payloads."
                ),
                "required": False,
                "default": True,
            },
            "simulate_latency_ms": {
                "type": "number",
                "label": "Simulated latency (ms)",
                "help_text": (
                    "Optional artificial delay added to every simulated "
                    "gateway operation, in milliseconds (0-10000). Useful "
                    "for testing loading states. Leave blank for none."
                ),
                "required": False,
                "default": 0,
            },
        }

    @property
    def supported_payment_methods(self) -> List[str]:
        return ["credit_card", "debit_card"]

    @property
    def supported_currencies(self) -> List[str]:
        return [
            "USD", "EUR", "GBP", "SGD", "AUD", "JPY", "CAD", "NZD", "CHF",
            "SEK", "NOK", "DKK", "HKD", "INR", "MYR", "THB", "PHP", "IDR",
            "VND", "KRW", "TWD", "CNY", "AED", "SAR", "ZAR", "BRL", "MXN",
            "PLN", "CZK", "HUF", "TRY", "ILS", "RON", "BGN", "ISK", "COP",
            "CLP", "PEN", "ARS", "EGP", "NGN", "KES", "PKR", "BDT", "LKR",
        ]

    @property
    def supported_countries(self) -> List[str]:
        return [
            "US", "GB", "AU", "CA", "SG", "HK", "JP", "NZ", "AT", "BE",
            "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR", "DE", "GR",
            "HU", "IE", "IT", "LV", "LT", "LU", "MT", "NL", "NO", "PL",
            "PT", "RO", "SK", "SI", "ES", "SE", "CH", "BR", "MX", "IN",
            "TH", "MY", "PH", "ID", "VN", "KR", "TW", "CN", "AE", "SA",
            "ZA", "TR", "IL", "AR", "CL", "CO", "PE", "EG", "NG", "KE",
            "PK", "BD", "LK", "IS",
        ]

    # ------------------------------------------------------------------
    # Credentials / connection
    # ------------------------------------------------------------------

    def validate_credentials(self, credentials: Dict[str, Any]) -> None:
        """
        The test gateway needs no credentials. Accepted settings are an
        optional strict_mode flag and an optional non-negative latency in
        milliseconds.
        """
        strict = credentials.get("strict_mode")
        if strict is not None and not isinstance(strict, bool):
            normalised = str(strict).strip().lower()
            if normalised not in ("", "true", "false", "1", "0", "yes", "no", "on", "off"):
                raise ValueError("strict_mode must be a boolean")

        latency = credentials.get("simulate_latency_ms")
        if latency in (None, ""):
            return
        try:
            latency_int = int(latency)
        except (TypeError, ValueError):
            raise ValueError("simulate_latency_ms must be a whole number of milliseconds")
        if latency_int < 0:
            raise ValueError("simulate_latency_ms must not be negative")
        if latency_int > MAX_LATENCY_MS:
            raise ValueError(
                f"simulate_latency_ms must not exceed {MAX_LATENCY_MS} ms"
            )

    def redact_credentials(self, credentials: Dict[str, Any]) -> Dict[str, Any]:
        """Nothing here is secret, but never mutate the input."""
        return dict(credentials)

    def test_connection(self) -> Dict[str, Any]:
        self._simulate_latency()
        return {
            "success": True,
            "message": (
                "Connected to the Spwig Test Gateway. "
                f"WARNING: {TEST_GATEWAY_NOTICE}"
            ),
            "details": {
                "test_gateway": True,
                "account_id": "test_acct_local",
                "account_name": "Spwig Test Gateway (simulated)",
                "environment": "simulated",
                "api_version": "1.0.0",
                "warning": TEST_GATEWAY_NOTICE,
            },
        }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _simulate_latency(self) -> None:
        """Sleep for the configured artificial latency (capped)."""
        latency = (
            self.credentials.get("simulate_latency_ms")
            or self.config.get("simulate_latency_ms")
            or 0
        )
        try:
            latency_int = min(int(latency), MAX_LATENCY_MS)
        except (TypeError, ValueError):
            latency_int = 0
        if latency_int > 0:
            time.sleep(latency_int / 1000.0)

    @staticmethod
    def _new_id(prefix: str) -> str:
        return f"{prefix}{uuid.uuid4().hex}"

    def _strict_enabled(self) -> bool:
        """
        Strict mode is ON unless explicitly disabled with
        ``{"strict_mode": false}`` in credentials or config. Permissive
        mode exists only so the platform's own unit tests can drive
        minimal payloads.
        """
        for source in (self.credentials, self.config):
            if not isinstance(source, dict) or "strict_mode" not in source:
                continue
            value = source.get("strict_mode")
            if isinstance(value, bool):
                return value
            if value is None:
                continue
            return str(value).strip().lower() not in ("false", "0", "no", "off")
        return True

    def _validate_checkout_request(
        self,
        amount: Decimal,
        currency: str,
        return_url: Any,
        cancel_url: Any,
        customer_email: Any,
        customer_name: Any,
        customer_country: Any,
        payment_method_types: Any,
        metadata: Any,
        customer_phone: Any = None,
        order_requires_shipping: Any = None,
    ) -> List[Dict[str, str]]:
        """
        Strict-mode validation of a checkout intent request, mirroring what
        real PSPs require (Stripe as the baseline; semantics per
        docs.stripe.com/api). Returns a list of error dicts, each carrying
        field / code / message. Empty list == valid.
        """
        errors: List[Dict[str, str]] = []

        def err(field: str, code: str, message: str) -> None:
            errors.append({"field": field, "code": code, "message": message})

        currency_code = str(currency or "").upper()

        # --- amount / currency ---------------------------------------
        minimum = MINIMUM_CHARGE_AMOUNTS.get(currency_code)
        if minimum is not None and amount < minimum:
            err(
                "amount",
                "amount_too_small",
                (
                    f"Amount {amount} {currency_code} is below the minimum "
                    f"charge of {minimum} {currency_code} (Stripe: "
                    f"amount_too_small, per-currency minimums at "
                    f"docs.stripe.com/currencies; Square refuses "
                    f"below-minimum amounts too)."
                ),
            )
        if currency_code in ZERO_DECIMAL_CURRENCIES and amount != amount.to_integral_value():
            err(
                "amount",
                "amount_not_whole_units",
                (
                    f"{currency_code} is a zero-decimal currency — amounts "
                    f"must be whole units, got {amount}. A fractional "
                    f"{currency_code} amount almost always means a "
                    f"minor-unit mis-scaling bug (Stripe: zero-decimal "
                    f"currencies, docs.stripe.com/currencies#zero-decimal)."
                ),
            )

        # --- redirect URLs -------------------------------------------
        if not _valid_http_url(return_url):
            err(
                "return_url",
                "invalid_return_url",
                (
                    "return_url is required and must be an http(s) URL "
                    "(Stripe: return_url / success_url; PayPal: "
                    "application_context.return_url; Square: redirect_url)."
                ),
            )
        if not _valid_http_url(cancel_url):
            err(
                "cancel_url",
                "invalid_cancel_url",
                (
                    "cancel_url is required and must be an http(s) URL "
                    "(Stripe Checkout: cancel_url; PayPal: "
                    "application_context.cancel_url)."
                ),
            )

        # --- customer fields -----------------------------------------
        if not (isinstance(customer_email, str) and customer_email.strip()):
            err(
                "customer_email",
                "customer_email_required",
                (
                    "customer_email is required (Stripe: receipt_email / "
                    "customer; PayPal: payer.email_address; Square: "
                    "buyer_email_address). Real PSPs need it for receipts "
                    "and fraud screening."
                ),
            )
        elif not _plausible_email(customer_email):
            # Deliberately does NOT echo the submitted value: these
            # messages are rendered in checkout UIs and written to logs,
            # and the value is customer-controlled at guest checkout.
            err(
                "customer_email",
                "customer_email_invalid",
                (
                    "customer_email is not a plausible email address "
                    "(Stripe rejects malformed receipt_email; Square "
                    "rejects malformed buyer_email_address)."
                ),
            )

        if not (isinstance(customer_name, str) and customer_name.strip()):
            err(
                "customer_name",
                "customer_name_required",
                (
                    "customer_name is required (Stripe: "
                    "billing_details[name]; PayPal: payer.name; card "
                    "networks require a cardholder/customer name for AVS "
                    "and dispute evidence)."
                ),
            )

        # Phone: required when the order ships physical goods — carriers
        # need a delivery contact number, and real PSPs feed it to fraud
        # screening (Stripe: billing_details[phone]; PayPal:
        # payer.phone; Square: buyer phone_number). Orders with no
        # physical delivery may omit it, but a supplied phone must at
        # least look dialable.
        has_phone = isinstance(customer_phone, str) and customer_phone.strip()
        if bool(order_requires_shipping) and not has_phone:
            err(
                "customer_phone",
                "customer_phone_required",
                (
                    "customer_phone is required for orders with physical "
                    "delivery (Stripe: billing_details[phone]; PayPal: "
                    "payer.phone). Carriers need a contact "
                    "number for delivery."
                ),
            )
        elif has_phone and not _plausible_phone(customer_phone):
            # No echo of the raw value — customer-controlled input.
            err(
                "customer_phone",
                "customer_phone_invalid",
                (
                    "customer_phone is not a plausible phone number — "
                    "expected at least 5 digits with an optional leading "
                    "+ and common separators."
                ),
            )

        if not (isinstance(customer_country, str) and customer_country.strip()):
            err(
                "customer_country",
                "customer_country_required",
                (
                    "customer_country is required (Stripe: "
                    "billing_details[address][country]; PayPal: "
                    "address.country_code). It is the "
                    "AVS baseline and drives payment-method availability."
                ),
            )
        else:
            country_code = customer_country.strip().upper()
            if not re.fullmatch(r"[A-Z]{2}", country_code):
                # No echo of the raw value — customer-controlled input.
                err(
                    "customer_country",
                    "customer_country_invalid",
                    (
                        "customer_country must be a 2-letter ISO 3166-1 "
                        "alpha-2 code (Stripe/PayPal both require ISO "
                        "country codes)."
                    ),
                )
            elif country_code not in self.supported_countries:
                err(
                    "customer_country",
                    "country_unsupported",
                    (
                        f"customer_country '{country_code}' is not "
                        f"supported by this gateway (real PSPs restrict "
                        f"serviceable countries — Stripe: "
                        f"country_unsupported)."
                    ),
                )

        # --- payment_method_types ------------------------------------
        if payment_method_types is not None:
            if not isinstance(payment_method_types, (list, tuple)) or not payment_method_types:
                err(
                    "payment_method_types",
                    "payment_method_types_invalid",
                    (
                        "payment_method_types must be a non-empty list of "
                        "method slugs when provided (Stripe: "
                        "payment_method_types)."
                    ),
                )
            elif not any(
                isinstance(m, str) and m.strip().lower() in ACCEPTED_PAYMENT_METHOD_TYPES
                for m in payment_method_types
            ):
                err(
                    "payment_method_types",
                    "payment_method_types_unsupported",
                    (
                        "None of the requested payment_method_types are "
                        "supported by this gateway (supports: card, "
                        "credit_card, debit_card). Stripe rejects unknown "
                        "payment_method_types the same way."
                    ),
                )

        # --- metadata (Stripe limits: 50 keys, 40-char keys, 500-char
        # values — docs.stripe.com/metadata) -------------------------
        if metadata is not None:
            if not isinstance(metadata, dict):
                err(
                    "metadata",
                    "metadata_invalid",
                    "metadata must be a mapping of string keys to values "
                    "(Stripe: metadata is a hash).",
                )
            else:
                if len(metadata) > 50:
                    err(
                        "metadata",
                        "metadata_too_many_keys",
                        f"metadata has {len(metadata)} keys; the maximum is "
                        f"50 (Stripe metadata limit).",
                    )
                # Keys/values may be request-supplied — echo a truncated,
                # repr-quoted key only (never values).
                for key, value in metadata.items():
                    if not isinstance(key, str) or len(key) > 40:
                        err(
                            "metadata",
                            "metadata_key_invalid",
                            f"metadata key {str(key)[:40]!r} must be a "
                            f"string of at most 40 characters (Stripe "
                            f"metadata limit).",
                        )
                        break
                for key, value in metadata.items():
                    if value is not None and len(str(value)) > 500:
                        err(
                            "metadata",
                            "metadata_value_too_long",
                            f"metadata value for key {str(key)[:40]!r} "
                            f"exceeds 500 characters (Stripe metadata "
                            f"limit).",
                        )
                        break

        return errors

    def _resolve_payment_method_card(
        self, payment_method: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """
        Extract card details from a payment_method dict.

        Accepts:
            {'type': 'credit_card', 'card': {number, exp_month, exp_year, cvc}}
            {'type': 'credit_card', 'token': 'test_tok_<magic-number>'}
        """
        card = payment_method.get("card")
        if isinstance(card, dict):
            return card

        token = payment_method.get("token", "")
        if isinstance(token, str) and token.startswith("test_tok_"):
            # Token encodes the magic card number: test_tok_4242424242424242
            number = token[len("test_tok_"):]
            return {
                "number": number,
                "exp_month": 12,
                "exp_year": datetime.now(dt_timezone.utc).year + 2,
                "cvc": "123",
            }
        return None

    def _validate_amount_currency(self, amount: Decimal, currency: str) -> None:
        if not isinstance(amount, Decimal):
            try:
                amount = Decimal(str(amount))
            except (InvalidOperation, TypeError, ValueError):
                raise ValueError("Amount must be a positive decimal number")
        if amount <= 0:
            raise ValueError("Amount must be positive")
        if currency.upper() not in self.supported_currencies:
            raise ValueError(f"Currency {currency} is not supported by the test gateway")

    def _decline_result(self, error: Dict[str, str], status: str = "failed") -> Dict[str, Any]:
        return {
            "success": False,
            "status": status,
            "message": error["message"],
            "error_code": error["code"],
            "error": dict(error),
            "raw_response": {
                "test_gateway": True,
                "error": dict(error),
            },
        }


    def _soft_decline_result(self, error: Dict[str, str]) -> Dict[str, Any]:
        """A retryable decline for the intent confirm path.

        Mirrors real PSP semantics (Stripe leaves a declined intent in
        requires_payment_method): success=True so the orchestrator does NOT
        mark the intent terminally failed, status requires_payment_method so
        the customer can correct the card and retry the same intent, and
        error_code/message so the platform persists and surfaces the reason.
        """
        return {
            "success": True,
            "status": "requires_payment_method",
            "requires_action": False,
            "action": None,
            "message": error["message"],
            "error_code": error["code"],
            "error": dict(error),
            "raw_response": {
                "test_gateway": True,
                "error": dict(error),
            },
        }

    # ------------------------------------------------------------------
    # Payment processing
    # ------------------------------------------------------------------

    def charge(
        self,
        amount: Decimal,
        currency: str,
        payment_method: Dict[str, Any],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        self._validate_amount_currency(amount, currency)
        self._simulate_latency()

        card = self._resolve_payment_method_card(payment_method or {})
        if card is None:
            return self._decline_result(
                {
                    "code": "invalid_payment_method",
                    "message": (
                        "The test gateway requires card details or a "
                        "test_tok_* token."
                    ),
                }
            )

        structural_error = _validate_card_details(card)
        if structural_error:
            return self._decline_result(structural_error)

        number = _normalise_card_number(card.get("number", ""))
        outcome = _evaluate_card_outcome(number)
        # Direct charge has no 3DS UI — treat the 3DS card as immediate
        # success (the challenge flow is exercised via confirm_payment_intent).
        if outcome["outcome"] == "declined":
            return self._decline_result(outcome)

        charge_id = self._new_id("test_ch_")
        now = datetime.now(dt_timezone.utc)
        _state_set(
            charge_id,
            {
                "object": "charge",
                "amount": str(amount),
                "currency": currency.upper(),
                "refunded": "0",
                "status": "completed",
                "last4": number[-4:],
                "created_at": now.isoformat(),
            },
        )

        return {
            "success": True,
            "transaction_id": charge_id,
            "provider_transaction_id": charge_id,
            "status": "completed",
            "amount": amount,
            "currency": currency.upper(),
            "payment_method_id": None,
            "created_at": now,
            "message": "Payment successful (simulated by the Spwig Test Gateway)",
            "raw_response": {
                "test_gateway": True,
                "id": charge_id,
                "amount": str(amount),
                "currency": currency.upper(),
                "status": "succeeded",
                "last4": number[-4:],
                "metadata": metadata or {},
            },
        }

    def authorize(
        self,
        amount: Decimal,
        currency: str,
        payment_method: Dict[str, Any],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        self._validate_amount_currency(amount, currency)
        self._simulate_latency()

        card = self._resolve_payment_method_card(payment_method or {})
        if card is None:
            return self._decline_result(
                {
                    "code": "invalid_payment_method",
                    "message": (
                        "The test gateway requires card details or a "
                        "test_tok_* token."
                    ),
                }
            )

        structural_error = _validate_card_details(card)
        if structural_error:
            return self._decline_result(structural_error)

        number = _normalise_card_number(card.get("number", ""))
        outcome = _evaluate_card_outcome(number)
        if outcome["outcome"] == "declined":
            return self._decline_result(outcome)

        auth_id = self._new_id("test_auth_")
        now = datetime.now(dt_timezone.utc)
        expires_at = now + timedelta(days=7)
        _state_set(
            auth_id,
            {
                "object": "authorization",
                "amount": str(amount),
                "currency": currency.upper(),
                "status": "authorized",
                "captured_amount": "0",
                "last4": number[-4:],
                "created_at": now.isoformat(),
                "expires_at": expires_at.isoformat(),
            },
        )

        return {
            "success": True,
            "authorization_id": auth_id,
            "provider_authorization_id": auth_id,
            "status": "authorized",
            "amount": amount,
            "currency": currency.upper(),
            "expires_at": expires_at,
            "created_at": now,
            "message": "Authorization successful (simulated by the Spwig Test Gateway)",
            "raw_response": {
                "test_gateway": True,
                "id": auth_id,
                "amount": str(amount),
                "currency": currency.upper(),
                "status": "authorized",
                "metadata": metadata or {},
            },
        }

    def capture(
        self,
        authorization_id: str,
        amount: Optional[Decimal] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        if not authorization_id:
            raise ValueError("Authorization ID is required")
        if amount is not None and amount <= 0:
            raise ValueError("Capture amount must be positive")

        self._simulate_latency()

        record = _state_get(authorization_id)
        if not record or record.get("object") != "authorization":
            return self._decline_result(
                {
                    "code": "authorization_not_found",
                    "message": (
                        "Unknown test authorization. The test gateway keeps "
                        "state in memory only — it does not survive restarts."
                    ),
                }
            )

        if record["status"] == "voided":
            return self._decline_result(
                {"code": "authorization_voided", "message": "Authorization was voided."}
            )
        if record["status"] == "captured":
            return self._decline_result(
                {
                    "code": "already_captured",
                    "message": "Authorization has already been captured.",
                }
            )

        authorized_amount = Decimal(record["amount"])
        capture_amount = amount if amount is not None else authorized_amount
        if capture_amount > authorized_amount:
            return self._decline_result(
                {
                    "code": "amount_too_large",
                    "message": "Capture amount exceeds the authorized amount.",
                }
            )

        charge_id = self._new_id("test_ch_")
        now = datetime.now(dt_timezone.utc)
        currency = record["currency"]

        record["status"] = "captured"
        record["captured_amount"] = str(capture_amount)
        record["charge_id"] = charge_id
        _state_set(authorization_id, record)

        _state_set(
            charge_id,
            {
                "object": "charge",
                "amount": str(capture_amount),
                "currency": currency,
                "refunded": "0",
                "status": "completed",
                "last4": record.get("last4", ""),
                "authorization_id": authorization_id,
                "created_at": now.isoformat(),
            },
        )

        return {
            "success": True,
            "transaction_id": charge_id,
            "provider_transaction_id": charge_id,
            "status": "completed",
            "amount": capture_amount,
            "currency": currency,
            "created_at": now,
            "message": "Capture successful (simulated by the Spwig Test Gateway)",
            "raw_response": {
                "test_gateway": True,
                "id": charge_id,
                "authorization_id": authorization_id,
                "amount": str(capture_amount),
                "currency": currency,
                "status": "succeeded",
                "metadata": metadata or {},
            },
        }

    def void(
        self, authorization_id: str, metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        if not authorization_id:
            raise ValueError("Authorization ID is required")

        self._simulate_latency()

        record = _state_get(authorization_id)
        if not record or record.get("object") != "authorization":
            return self._decline_result(
                {
                    "code": "authorization_not_found",
                    "message": (
                        "Unknown test authorization. The test gateway keeps "
                        "state in memory only — it does not survive restarts."
                    ),
                }
            )

        if record["status"] == "captured":
            return self._decline_result(
                {
                    "code": "already_captured",
                    "message": "Cannot void a captured authorization — refund instead.",
                }
            )
        if record["status"] == "voided":
            return self._decline_result(
                {"code": "already_voided", "message": "Authorization is already voided."}
            )

        record["status"] = "voided"
        _state_set(authorization_id, record)

        return {
            "success": True,
            "authorization_id": authorization_id,
            "status": "voided",
            "message": "Authorization voided (simulated by the Spwig Test Gateway)",
            "raw_response": {
                "test_gateway": True,
                "id": authorization_id,
                "status": "voided",
                "metadata": metadata or {},
            },
        }

    def refund(
        self,
        transaction_id: str,
        amount: Optional[Decimal] = None,
        reason: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        if not transaction_id:
            raise ValueError("Transaction ID is required")
        if amount is not None and amount <= 0:
            raise ValueError("Refund amount must be positive")

        self._simulate_latency()

        # Accept either a charge id or an intent id (the platform stores
        # the provider_intent_id on checkout payments).
        record = _state_get(transaction_id)
        charge_id = transaction_id
        if record and record.get("object") == "intent":
            charge_id = record.get("charge_id") or ""
            record = _state_get(charge_id) if charge_id else None

        if not record or record.get("object") != "charge":
            return self._decline_result(
                {
                    "code": "charge_not_found",
                    "message": (
                        "Unknown test charge. The test gateway keeps state in "
                        "memory only — it does not survive restarts."
                    ),
                }
            )

        charged = Decimal(record["amount"])
        already_refunded = Decimal(record.get("refunded", "0"))
        refundable = charged - already_refunded
        refund_amount = amount if amount is not None else refundable

        if refundable <= 0:
            return self._decline_result(
                {
                    "code": "charge_already_refunded",
                    "message": "This charge has already been fully refunded.",
                }
            )
        if refund_amount > refundable:
            return self._decline_result(
                {
                    "code": "amount_too_large",
                    "message": (
                        f"Refund amount exceeds the refundable balance "
                        f"({refundable} {record['currency']})."
                    ),
                }
            )

        record["refunded"] = str(already_refunded + refund_amount)
        _state_set(charge_id, record)

        refund_id = self._new_id("test_re_")
        now = datetime.now(dt_timezone.utc)

        return {
            "success": True,
            "refund_id": refund_id,
            "provider_refund_id": refund_id,
            "status": "completed",
            "amount": refund_amount,
            "currency": record["currency"],
            "created_at": now,
            "message": "Refund successful (simulated by the Spwig Test Gateway)",
            "raw_response": {
                "test_gateway": True,
                "id": refund_id,
                "charge_id": charge_id,
                "amount": str(refund_amount),
                "currency": record["currency"],
                "status": "succeeded",
                "reason": reason or "",
                "metadata": metadata or {},
            },
        }

    # ------------------------------------------------------------------
    # Webhooks — the test gateway never sends webhooks
    # ------------------------------------------------------------------

    def verify_webhook_signature(self, payload: bytes, signature: str, **kwargs) -> bool:
        """The test gateway never sends webhooks; reject everything."""
        return False

    def handle_webhook(self, event_type: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """The test gateway never sends webhooks; ignore everything."""
        return {
            "action": "ignored",
            "status": "unknown",
            "message": "The Spwig Test Gateway does not emit webhooks.",
            "raw_event": payload,
        }

    # ------------------------------------------------------------------
    # Checkout orchestration (payment intents)
    # ------------------------------------------------------------------

    def create_payment_intent_for_checkout(
        self,
        amount: Decimal,
        currency: str,
        return_url: str,
        cancel_url: str,
        customer_email: Optional[str] = None,
        customer_name: Optional[str] = None,
        customer_country: Optional[str] = None,
        customer_phone: Optional[str] = None,
        order_requires_shipping: Optional[bool] = None,
        payment_method_types: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """
        Create a simulated payment intent for embedded checkout.

        Always uses the embedded/plugin-handler mode: the platform serves
        our checkout-handler.js, which renders a local card form and
        confirms via /api/payments/intents/<uuid>/confirm/.

        In strict mode (the default) the request is validated the way a
        real PSP would validate it — see _validate_checkout_request. All
        failures are aggregated into one success=False response whose
        message names every missing/invalid field and which real
        providers require it.
        """

        def _failure(message: str, errors: Optional[List[Dict[str, str]]] = None) -> Dict[str, Any]:
            return {
                "success": False,
                "message": message,
                "error_code": (errors[0]["code"] if errors else "invalid_request"),
                "errors": errors or [],
                "provider_intent_id": "",
                "client_secret": "",
                "checkout_url": "",
                "status": "failed",
                "requires_action": False,
                "action": None,
                "expires_at": None,
                "raw_response": {
                    "test_gateway": True,
                    "error": message,
                    "errors": errors or [],
                },
            }

        try:
            self._validate_amount_currency(amount, currency)
        except ValueError as exc:
            return _failure(str(exc))

        try:
            amount = amount if isinstance(amount, Decimal) else Decimal(str(amount))
        except (InvalidOperation, TypeError, ValueError):
            return _failure("Amount must be a positive decimal number")

        if self._strict_enabled():
            errors = self._validate_checkout_request(
                amount=amount,
                currency=currency,
                return_url=return_url,
                cancel_url=cancel_url,
                customer_email=customer_email,
                customer_name=customer_name,
                customer_country=customer_country,
                payment_method_types=payment_method_types,
                metadata=metadata,
                customer_phone=customer_phone,
                order_requires_shipping=order_requires_shipping,
            )
            if errors:
                message = "Test Gateway strict mode rejected this checkout request: " + " | ".join(
                    e["message"] for e in errors
                )
                logger.warning(
                    "[TestGateway strict] intent creation rejected: %s",
                    "; ".join(f"{e['field']}:{e['code']}" for e in errors),
                )
                return _failure(message, errors)

        self._simulate_latency()

        intent_id = self._new_id("test_pi_")
        client_secret = f"{intent_id}_secret_{uuid.uuid4().hex}"
        now = datetime.now(dt_timezone.utc)
        expires_at = now + timedelta(hours=1)

        _state_set(
            intent_id,
            {
                "object": "intent",
                "amount": str(amount),
                "currency": currency.upper(),
                "status": "requires_payment_method",
                "charge_id": "",
                "last4": "",
                "created_at": now.isoformat(),
            },
        )

        # handler_config is included both here and mirrored into
        # raw_response: the platform's generic serializer branch builds
        # {intent_id, currency} from raw_response["id"]/["currency"].
        handler_config = {
            "intent_id": intent_id,
            "currency": currency.upper(),
            "amount": str(amount),
            "test_gateway": True,
        }

        return {
            "success": True,
            "provider_intent_id": intent_id,
            "client_secret": client_secret,
            "checkout_url": "",  # embedded only — no hosted page
            "status": "requires_payment_method",
            "requires_action": False,
            "action": None,
            "expires_at": expires_at,
            "handler_config": handler_config,
            "raw_response": {
                "test_gateway": True,
                "id": intent_id,
                "amount": str(amount),
                "currency": currency.upper(),
                "status": "requires_payment_method",
                "customer_email": customer_email or "",
                "metadata": metadata or {},
                "warning": TEST_GATEWAY_NOTICE,
            },
        }

    def retrieve_payment_intent(self, intent_id: str) -> Dict[str, Any]:
        if not intent_id:
            raise ValueError("Intent ID is required")

        record = _state_get(intent_id)
        if not record or record.get("object") != "intent":
            # Unknown intents (e.g. after a process restart) must NOT be
            # reported as failed — the platform's status-sync would then
            # mark a live checkout as failed. Report 'created' and let
            # the confirm flow decide the real outcome.
            return {
                "success": True,
                "status": "created",
                "provider_status": "unknown",
                "requires_action": False,
                "action": None,
                "payment_method_type": None,
                "payment_method_last4": None,
                "error": None,
                "raw_response": {"test_gateway": True, "id": intent_id},
            }

        # Delayed-capture magic trigger (.19 amounts): flip 'processing'
        # to 'succeeded' once the simulated webhook delay has elapsed and
        # raise the charge that the confirm step deferred.
        if record.get("status") == "processing":
            ready_at = float(record.get("processing_ready_at") or 0)
            if time.time() >= ready_at:
                charge_id = self._new_id("test_ch_")
                _state_set(
                    charge_id,
                    {
                        "object": "charge",
                        "amount": record.get("amount", "0"),
                        "currency": record.get("currency", "USD"),
                        "refunded": "0",
                        "status": "completed",
                        "last4": record.get("last4", ""),
                        "intent_id": intent_id,
                        "created_at": datetime.now(dt_timezone.utc).isoformat(),
                    },
                )
                record["charge_id"] = charge_id
                record["status"] = "succeeded"
                record.pop("processing_ready_at", None)
                _state_set(intent_id, record)

        status = record.get("status", "requires_payment_method")
        status_map = {
            "requires_payment_method": "created",
            "requires_action": "requires_action",
            "processing": "processing",
            "succeeded": "succeeded",
            "failed": "failed",
            "canceled": "canceled",
        }
        requires_action = status == "requires_action"

        # A fresh intent reports "created"; after a soft decline (record
        # carries an error) it reports requires_payment_method — still
        # non-terminal, but truthful about needing a new card.
        mapped_status = status_map.get(status, "created")
        if status == "requires_payment_method" and record.get("error"):
            mapped_status = "requires_payment_method"

        result = {
            "success": True,
            "status": mapped_status,
            "provider_status": status,
            "requires_action": requires_action,
            "action": None,
            "payment_method_type": "card" if record.get("last4") else None,
            "payment_method_last4": record.get("last4") or None,
            "error": record.get("error"),
            "raw_response": {
                "test_gateway": True,
                "id": intent_id,
                "amount": record.get("amount"),
                "currency": record.get("currency"),
                "status": status,
            },
        }
        if requires_action:
            result["action"] = {
                "type": "test_3ds_challenge",
                "url": None,
                "data": {"test_gateway": True},
            }
        return result

    def confirm_payment_intent(
        self, intent_id: str, confirmation_data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Confirm a simulated payment intent with card details.

        Called by PaymentOrchestrationService.confirm_payment_intent when
        the checkout handler POSTs to
        /api/payments/intents/<uuid>/confirm/ with:

            {"payment_method_data": {
                "card": {"number", "exp_month", "exp_year", "cvc"},
                "cardholder_name": "...",
                "three_ds_completed": true|false,   # 3DS step only
                "three_ds_failed": true             # 3DS step only
            }}

        The magic card number decides the outcome. Card 4000...3220
        returns success=True with requires_action + a
        'test_3ds_challenge' action on the first call; the handler shows
        a fake authentication modal and re-confirms with
        three_ds_completed=true.
        """
        if not intent_id:
            raise ValueError("Intent ID is required")

        self._simulate_latency()

        data = confirmation_data or {}
        card = data.get("card")
        if not isinstance(card, dict):
            return self._soft_decline_result(
                {
                    "code": "missing_card",
                    "message": "Card details are required to confirm a test payment.",
                }
            )

        structural_error = _validate_card_details(card)
        if structural_error:
            return self._soft_decline_result(structural_error)

        if self._strict_enabled():
            cardholder_name = data.get("cardholder_name")
            if not (isinstance(cardholder_name, str) and cardholder_name.strip()):
                return self._soft_decline_result(
                    {
                        "code": "cardholder_name_required",
                        "message": (
                            "The cardholder name is required (Stripe: "
                            "billing_details[name]; Square: "
                            "cardholder_name). Enter the name as it appears "
                            "on the card."
                        ),
                    }
                )
            strict_number = _normalise_card_number(card.get("number", ""))
            if not _luhn_valid(strict_number):
                return self._soft_decline_result(
                    {
                        "code": "incorrect_number",
                        "message": (
                            "The card number fails checksum (Luhn) "
                            "validation — real PSPs reject it before "
                            "routing (Stripe: incorrect_number). Use a "
                            "documented magic test card."
                        ),
                    }
                )

        number = _normalise_card_number(card.get("number", ""))
        last4 = number[-4:]
        outcome = _evaluate_card_outcome(number)

        record = _state_get(intent_id) or {
            "object": "intent",
            "amount": "0",
            "currency": "USD",
            "status": "requires_payment_method",
            "charge_id": "",
            "last4": "",
            "created_at": datetime.now(dt_timezone.utc).isoformat(),
        }

        def _persist(status: str, error: Optional[Dict[str, str]] = None) -> None:
            record["status"] = status
            record["last4"] = last4
            if error:
                record["error"] = dict(error)
            _state_set(intent_id, record)

        # Simulated 3DS failure (customer clicked "Fail authentication")
        if data.get("three_ds_failed"):
            error = {
                "code": "authentication_failed",
                "message": "3D Secure authentication failed. (Simulated failure.)",
            }
            _persist("requires_payment_method", error)
            return self._soft_decline_result(error)

        if outcome["outcome"] == "requires_3ds" and not data.get("three_ds_completed"):
            _persist("requires_action")
            return {
                "success": True,
                "status": "requires_action",
                "requires_action": True,
                "action": {
                    "type": "test_3ds_challenge",
                    "url": None,
                    "data": {
                        "test_gateway": True,
                        "message": (
                            "Simulated 3D Secure challenge — complete the "
                            "authentication step shown by the test gateway."
                        ),
                    },
                },
                "payment_method_type": "card",
                "payment_method_last4": last4,
                "message": "Additional authentication required (simulated 3DS)",
                "error": None,
                "raw_response": {
                    "test_gateway": True,
                    "id": intent_id,
                    "status": "requires_action",
                    "last4": last4,
                },
            }

        if outcome["outcome"] == "declined":
            # Soft decline: the intent stays retryable, mirroring real PSPs
            _persist("requires_payment_method", {"code": outcome["code"], "message": outcome["message"]})
            return self._soft_decline_result(outcome)

        # Magic trigger: amounts ending in .19 simulate an asynchronous
        # capture. Confirm returns 'processing'; the intent flips to
        # 'succeeded' on the first retrieve after PROCESSING_DELAY_SECONDS
        # (a stand-in for the webhook a real PSP would send). Exercises
        # the platform's status-polling path.
        if _is_delayed_success_amount(record.get("amount", "0")):
            ready_at = time.time() + PROCESSING_DELAY_SECONDS
            record["processing_ready_at"] = ready_at
            record.pop("error", None)
            _persist("processing")
            return {
                "success": True,
                "status": "processing",
                "requires_action": False,
                "action": None,
                "payment_method_type": "card",
                "payment_method_last4": last4,
                "message": (
                    "Payment accepted and processing (simulated "
                    "webhook-style delay — the intent will succeed in a "
                    "few seconds; keep polling the intent status)."
                ),
                "error": None,
                "raw_response": {
                    "test_gateway": True,
                    "id": intent_id,
                    "status": "processing",
                    "amount": record.get("amount"),
                    "currency": record.get("currency"),
                    "last4": last4,
                },
            }

        # Success (4242... or 3220... after the 3DS step)
        charge_id = self._new_id("test_ch_")
        now = datetime.now(dt_timezone.utc)
        _state_set(
            charge_id,
            {
                "object": "charge",
                "amount": record.get("amount", "0"),
                "currency": record.get("currency", "USD"),
                "refunded": "0",
                "status": "completed",
                "last4": last4,
                "intent_id": intent_id,
                "created_at": now.isoformat(),
            },
        )
        record["charge_id"] = charge_id
        _persist("succeeded")

        return {
            "success": True,
            "status": "succeeded",
            "requires_action": False,
            "action": None,
            "payment_method_type": "card",
            "payment_method_last4": last4,
            "message": "Payment confirmed (simulated by the Spwig Test Gateway)",
            "error": None,
            "raw_response": {
                "test_gateway": True,
                "id": intent_id,
                "charge_id": charge_id,
                "amount": record.get("amount"),
                "currency": record.get("currency"),
                "status": "succeeded",
                "last4": last4,
            },
        }

    def cancel_payment_intent(
        self, intent_id: str, cancellation_reason: Optional[str] = None
    ) -> Dict[str, Any]:
        if not intent_id:
            raise ValueError("Intent ID is required")

        record = _state_get(intent_id)
        if record and record.get("object") == "intent":
            if record.get("status") == "succeeded":
                return self._decline_result(
                    {
                        "code": "intent_already_succeeded",
                        "message": "Cannot cancel a payment that already succeeded.",
                    }
                )
            if record.get("status") == "processing":
                # Mirrors Stripe: an intent in 'processing' cannot be
                # canceled — the asynchronous capture is already in flight.
                return self._decline_result(
                    {
                        "code": "intent_processing",
                        "message": (
                            "Cannot cancel a payment that is processing "
                            "(Stripe: only requires_* intents are "
                            "cancelable)."
                        ),
                    }
                )
            record["status"] = "canceled"
            record["cancellation_reason"] = cancellation_reason or ""
            _state_set(intent_id, record)

        return {
            "success": True,
            "status": "canceled",
            "message": "Payment intent canceled (simulated by the Spwig Test Gateway)",
            "raw_response": {
                "test_gateway": True,
                "id": intent_id,
                "status": "canceled",
                "cancellation_reason": cancellation_reason or "",
            },
        }
