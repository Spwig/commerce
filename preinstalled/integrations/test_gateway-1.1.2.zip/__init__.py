"""
Spwig Test Gateway for the Spwig eCommerce Platform
Version: 1.1.2

SIMULATED payments for testing and development only. No real money moves.
"""
from .provider import TestGatewayProvider

__version__ = "1.1.2"
__all__ = ["TestGatewayProvider"]
