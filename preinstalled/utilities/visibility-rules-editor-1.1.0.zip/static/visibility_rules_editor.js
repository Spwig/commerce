/* Copyright (c) 2025-2026 Spwig. Licensed under AGPL-3.0. */

/**
 * Visibility Rules Editor Utility v1.1.0
 *
 * Embeddable editor for the shared Spwig visibility engine. It attaches reusable
 * visibility RuleGroups to ANY target — a page-builder element, a menu item, or a
 * header/footer widget placement — persisting the target's rule_groups /
 * visibility_rules M2M through the neutral /api/visibility/ endpoints. The same
 * rules then gate the object server-side (market/geo, language, currency, time,
 * and per-visitor auth/cart/device conditions).
 *
 * v1.1.0 reworks the editor to be RuleGroup-centric and self-persisting: it no
 * longer emits ad-hoc JSON that nothing evaluated. Instead it reads/writes the
 * real M2M, offers a "quick create" that materialises a real VisibilityRule +
 * RuleGroup, and links out to the full rule-group builder for advanced authoring.
 *
 * Options:
 *   targetType  'element' | 'menuitem' | 'widgetplacement'  (default 'element')
 *   targetId    the object's pk (falls back to options.elementId, or the
 *               enclosing .element-properties-form's data-elementId)
 *   onApply(ids), onChange(ids), onClose()
 */

class VisibilityRulesEditor {
  constructor(options = {}) {
    this.options = {
      onChange: options.onChange || (() => {}),
      onApply: options.onApply || (() => {}),
      onClose: options.onClose || (() => {}),
    };

    this.targetType = options.targetType || 'element';
    this.targetId = options.targetId || options.elementId || null;

    this.API = {
      groups: '/api/visibility/rule-groups/',
      attach: '/api/visibility/attach/',
      quick: '/api/visibility/quick-rule/',
    };

    // Curated quick-create rule types. Anything more advanced (nested groups,
    // regex, multi-rule logic) is authored in the full rule-group builder.
    this.quickRuleTypes = [
      {
        key: 'members',
        label: 'Logged-in members only',
        icon: 'fa-user-check',
        rule_type: 'user_logged_in',
        operator: 'is_true',
        value: { value: true },
      },
      {
        key: 'guests',
        label: 'Guests only',
        icon: 'fa-user-slash',
        rule_type: 'user_logged_in',
        operator: 'is_false',
        value: { value: true },
      },
      {
        key: 'market',
        label: 'Market / region',
        icon: 'fa-globe',
        rule_type: 'geo_region',
        operator: 'equals',
        field: { name: 'code', placeholder: 'Region code (e.g. NZ)', transform: 'upper' },
      },
      {
        key: 'currency',
        label: 'Selected currency',
        icon: 'fa-coins',
        rule_type: 'selected_currency',
        operator: 'equals',
        field: { name: 'code', placeholder: 'Currency (e.g. NZD)', transform: 'upper' },
      },
      {
        key: 'device',
        label: 'Device type',
        icon: 'fa-mobile-alt',
        rule_type: 'device_type',
        operator: 'equals',
        select: {
          name: 'device',
          options: [
            { value: 'mobile', label: 'Mobile' },
            { value: 'tablet', label: 'Tablet' },
            { value: 'desktop', label: 'Desktop' },
          ],
        },
      },
      {
        key: 'cart_value',
        label: 'Cart value at least',
        icon: 'fa-shopping-cart',
        rule_type: 'cart_value',
        operator: 'greater_than',
        field: { name: 'amount', placeholder: 'Amount (e.g. 50)', type: 'number' },
      },
    ];

    this.available = []; // [{id, name, summary, rules_count, logic_operator}]
    this.selectedIds = new Set();

    this.targetElement = null;
    this.triggerButton = null;
    this.summaryDisplay = null;
    this.popup = null;
    this.isOpen = false;
    this.dragCleanup = null;

    this.handleOutsideClick = this.handleOutsideClick.bind(this);
  }

  // --- fetch helpers -------------------------------------------------------

  _csrf() {
    // The CSRF cookie is HttpOnly on Spwig, so JS can't read it. Read the token
    // from the page instead — the builder pages render a <meta name="csrf-token">
    // tag (and Django forms a csrfmiddlewaretoken input), matching how the page
    // builder's own AJAX obtains it. Cookie is only a last resort.
    const meta = document.querySelector('meta[name="csrf-token"]');
    if (meta && meta.content) return meta.content;
    const input = document.querySelector('[name=csrfmiddlewaretoken]');
    if (input && input.value) return input.value;
    if (window.AdminUtils && typeof window.AdminUtils.getCsrfToken === 'function') {
      return window.AdminUtils.getCsrfToken();
    }
    const m = document.cookie.match(/(?:^|;\s*)csrftoken=([^;]+)/);
    return m ? decodeURIComponent(m[1]) : '';
  }

  _headers(withJson) {
    const h = { 'X-Requested-With': 'XMLHttpRequest', 'X-CSRFToken': this._csrf() };
    if (withJson) h['Content-Type'] = 'application/json';
    return h;
  }

  // --- lifecycle -----------------------------------------------------------

  attach(element, currentValue) {
    this.targetElement = element;

    if (!this.targetId) {
      const form = element.closest('.element-properties-form');
      if (form) this.targetId = form.dataset.elementId;
    }

    // Fall back to any ids already on the input (page builder may have stored a
    // list); the server GET below is authoritative when a target id is known.
    this._parseValue(currentValue);

    this._createTrigger();
    this._loadState();
  }

  _parseValue(value) {
    if (!value) return;
    try {
      const parsed = typeof value === 'string' ? JSON.parse(value) : value;
      if (Array.isArray(parsed)) {
        parsed.forEach((x) => {
          const id = x && typeof x === 'object' ? x.rule_group_id ?? x.id : x;
          const n = parseInt(id, 10);
          if (!isNaN(n)) this.selectedIds.add(n);
        });
      }
    } catch (e) {
      /* ignore malformed legacy value */
    }
  }

  async _loadState() {
    try {
      const r = await fetch(this.API.groups, {
        headers: this._headers(false),
        credentials: 'same-origin',
      });
      if (r.ok) {
        const d = await r.json();
        this.available = (d && d.rule_groups) || [];
      }
    } catch (e) {
      this.available = [];
    }

    if (this.targetId) {
      try {
        const url = `${this.API.attach}?target_type=${encodeURIComponent(
          this.targetType
        )}&target_id=${encodeURIComponent(this.targetId)}`;
        const r = await fetch(url, { headers: this._headers(false), credentials: 'same-origin' });
        if (r.ok) {
          const d = await r.json();
          this.selectedIds = new Set((d.rule_group_ids || []).map(Number));
        }
      } catch (e) {
        /* keep the parsed fallback */
      }
    }

    this._updateSummary();
    if (this.isOpen) this._renderGroupList();
  }

  // --- trigger + summary ---------------------------------------------------

  _createTrigger() {
    const wrapper = document.createElement('div');
    wrapper.className = 'visibility-rules-trigger-wrapper';

    this.summaryDisplay = document.createElement('div');
    this.summaryDisplay.className = 'visibility-rules-summary';
    wrapper.appendChild(this.summaryDisplay);

    this.triggerButton = document.createElement('button');
    this.triggerButton.type = 'button';
    this.triggerButton.className = 'util-btn util-btn-primary visibility-rules-trigger';
    this.triggerButton.innerHTML = '<i class="fas fa-eye"></i>';
    this.triggerButton.title = 'Configure visibility rules';
    wrapper.appendChild(this.triggerButton);

    this.targetElement.style.display = 'none';
    this.targetElement.parentNode.insertBefore(wrapper, this.targetElement.nextSibling);

    this.triggerButton.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      this.open();
    });

    this._updateSummary();
  }

  _updateSummary() {
    if (!this.summaryDisplay) return;
    const count = this.selectedIds.size;
    if (count === 0) {
      this.summaryDisplay.innerHTML =
        '<span class="visibility-rules-empty"><i class="fas fa-eye"></i> Always visible</span>';
      return;
    }
    const names = this.available
      .filter((g) => this.selectedIds.has(g.id))
      .slice(0, 3)
      .map((g) => `<i class="fas fa-layer-group" title="${this._esc(g.name)}"></i>`)
      .join('');
    this.summaryDisplay.innerHTML = `<span class="visibility-rules-active">${names}<span class="rule-count">${count} rule group${count !== 1 ? 's' : ''}</span></span>`;
  }

  // --- popup ---------------------------------------------------------------

  open() {
    if (this.isOpen) return;
    this._createPopup();
    this.isOpen = true;
    setTimeout(() => document.addEventListener('mousedown', this.handleOutsideClick), 100);
  }

  close() {
    if (!this.isOpen) return;
    if (this.popup) {
      this.popup.remove();
      this.popup = null;
    }
    if (this.dragCleanup) {
      this.dragCleanup();
      this.dragCleanup = null;
    }
    document.removeEventListener('mousedown', this.handleOutsideClick);
    this.isOpen = false;
    this.options.onClose();
  }

  handleOutsideClick(e) {
    if (
      this.popup &&
      !this.popup.contains(e.target) &&
      this.triggerButton &&
      !this.triggerButton.contains(e.target)
    ) {
      this.close();
    }
  }

  _manageUrl() {
    const lang = document.documentElement.lang || 'en';
    return `/${lang}/admin/visibility/rulegroup/`;
  }

  _createPopup() {
    this.popup = document.createElement('div');
    this.popup.className = 'utility-popup visibility-rules-popup';
    this.popup.innerHTML = `
      <div class="utility-header">
        <span class="utility-title"><i class="fas fa-eye"></i> Visibility Rules</span>
        <div class="utility-tools">
          <button type="button" class="utility-close" title="Close"><i class="fas fa-times"></i></button>
        </div>
      </div>
      <div class="utility-body">
        <div class="visibility-rules-description">
          <p>Attach one or more rule groups. The element is shown when any attached
          group matches. No groups = always visible.</p>
        </div>
        <div class="visibility-rules-list"></div>
        <div class="visibility-rules-add">
          <button type="button" class="btn-quick-rule"><i class="fas fa-bolt"></i> Quick rule</button>
          <a href="${this._manageUrl()}" target="_blank" rel="noopener" class="btn-manage-rules">
            <i class="fas fa-cog"></i> Manage rule groups
          </a>
        </div>
        <div class="visibility-quick-form"></div>
      </div>
      <div class="utility-footer">
        <button type="button" class="btn btn-clear">Cancel</button>
        <button type="button" class="btn btn-apply">Apply</button>
      </div>
    `;

    const rect = this.triggerButton.getBoundingClientRect();
    this.popup.style.position = 'fixed';
    this.popup.style.top = `${rect.bottom + 10}px`;
    this.popup.style.left = `${Math.max(10, rect.left - 200)}px`;
    this.popup.style.zIndex = '10001';
    document.body.appendChild(this.popup);

    this._renderGroupList();
    this._wirePopup();
    this._makeDraggable();
  }

  _renderGroupList() {
    if (!this.popup) return;
    const listEl = this.popup.querySelector('.visibility-rules-list');
    if (!listEl) return;

    if (this.available.length === 0) {
      listEl.innerHTML = `
        <div class="visibility-rules-empty-state">
          <i class="fas fa-layer-group"></i>
          <p>No rule groups yet</p>
          <p class="hint">Create one with "Quick rule" or the rule-group builder.</p>
        </div>`;
      return;
    }

    listEl.innerHTML = this.available
      .map((g) => {
        const checked = this.selectedIds.has(g.id) ? 'checked' : '';
        const summary = g.summary || `${g.rules_count} rule(s) (${g.logic_operator})`;
        return `
          <label class="visibility-rule-item selectable" data-group-id="${g.id}">
            <input type="checkbox" class="rule-group-check" value="${g.id}" ${checked}>
            <span class="rule-icon"><i class="fas fa-layer-group"></i></span>
            <span class="rule-info">
              <span class="rule-label">${this._esc(g.name)}</span>
              <span class="rule-config">${this._esc(summary)}</span>
            </span>
          </label>`;
      })
      .join('');

    listEl.querySelectorAll('.rule-group-check').forEach((cb) => {
      cb.addEventListener('change', (e) => {
        const id = parseInt(e.target.value, 10);
        if (e.target.checked) this.selectedIds.add(id);
        else this.selectedIds.delete(id);
      });
    });
  }

  _wirePopup() {
    this.popup.querySelector('.utility-close').addEventListener('click', () => this.close());
    this.popup.querySelector('.btn-clear').addEventListener('click', () => this.close());
    this.popup.querySelector('.btn-apply').addEventListener('click', () => this.apply());
    this.popup
      .querySelector('.btn-quick-rule')
      .addEventListener('click', () => this._toggleQuickForm());
  }

  // --- quick create --------------------------------------------------------

  _toggleQuickForm() {
    const host = this.popup.querySelector('.visibility-quick-form');
    if (host.childElementCount) {
      host.innerHTML = '';
      return;
    }
    const opts = this.quickRuleTypes
      .map((t) => `<option value="${t.key}">${this._esc(t.label)}</option>`)
      .join('');
    host.innerHTML = `
      <div class="rule-config-header"><h4><i class="fas fa-bolt"></i> Quick rule</h4></div>
      <div class="control-group">
        <label>Condition</label>
        <select class="quick-type select-field">${opts}</select>
      </div>
      <div class="quick-field"></div>
      <div class="rule-config-actions">
        <button type="button" class="btn btn-clear quick-cancel">Cancel</button>
        <button type="button" class="btn btn-apply quick-add">Create &amp; attach</button>
      </div>
      <div class="quick-error" role="alert"></div>
    `;
    const typeSel = host.querySelector('.quick-type');
    const renderField = () => this._renderQuickField(host, this._quickType(typeSel.value));
    typeSel.addEventListener('change', renderField);
    renderField();
    host.querySelector('.quick-cancel').addEventListener('click', () => {
      host.innerHTML = '';
    });
    host.querySelector('.quick-add').addEventListener('click', () => this._submitQuick(host, typeSel));
  }

  _quickType(key) {
    return this.quickRuleTypes.find((t) => t.key === key);
  }

  _renderQuickField(host, def) {
    const fieldHost = host.querySelector('.quick-field');
    if (!def) {
      fieldHost.innerHTML = '';
      return;
    }
    if (def.select) {
      const opts = def.select.options
        .map((o) => `<option value="${o.value}">${this._esc(o.label)}</option>`)
        .join('');
      fieldHost.innerHTML = `<div class="control-group"><label>Value</label><select class="quick-value select-field">${opts}</select></div>`;
    } else if (def.field) {
      const type = def.field.type || 'text';
      fieldHost.innerHTML = `<div class="control-group"><label>Value</label><input type="${type}" class="quick-value" placeholder="${this._esc(
        def.field.placeholder || ''
      )}"></div>`;
    } else {
      fieldHost.innerHTML = '';
    }
  }

  async _submitQuick(host, typeSel) {
    const def = this._quickType(typeSel.value);
    const errEl = host.querySelector('.quick-error');
    errEl.textContent = '';
    if (!def) return;

    let value = def.value || {};
    if (def.select || def.field) {
      const input = host.querySelector('.quick-value');
      let raw = input ? input.value.trim() : '';
      if (!raw) {
        errEl.textContent = 'Please enter a value.';
        return;
      }
      if (def.field && def.field.transform === 'upper') raw = raw.toUpperCase();
      value = { value: raw };
    }

    const payload = {
      rule_type: def.rule_type,
      operator: def.operator,
      value,
      name: def.label,
    };

    try {
      const r = await fetch(this.API.quick, {
        method: 'POST',
        headers: this._headers(true),
        credentials: 'same-origin',
        body: JSON.stringify(payload),
      });
      const d = await r.json().catch(() => ({}));
      if (!r.ok || !d.success) {
        errEl.textContent = (d && d.error) || 'Could not create the rule.';
        return;
      }
      const group = d.rule_group;
      this.available.unshift(group);
      this.selectedIds.add(group.id);
      host.innerHTML = '';
      this._renderGroupList();
    } catch (e) {
      errEl.textContent = 'Network error creating the rule.';
    }
  }

  // --- apply ---------------------------------------------------------------

  async apply() {
    const ids = Array.from(this.selectedIds);

    // Persist directly to the M2M when we know the target; the input value is
    // kept in sync as a hint for any builder that also reads it.
    if (this.targetId) {
      try {
        const r = await fetch(this.API.attach, {
          method: 'POST',
          headers: this._headers(true),
          credentials: 'same-origin',
          body: JSON.stringify({
            target_type: this.targetType,
            target_id: this.targetId,
            rule_group_ids: ids,
          }),
        });
        const d = await r.json().catch(() => ({}));
        if (r.ok && d.success && Array.isArray(d.rule_group_ids)) {
          this.selectedIds = new Set(d.rule_group_ids.map(Number));
        }
      } catch (e) {
        /* leave local selection; the input hint still carries the ids */
      }
    }

    const finalIds = Array.from(this.selectedIds);
    if (this.targetElement) {
      this.targetElement.value = JSON.stringify(finalIds);
      this.targetElement.dispatchEvent(new Event('change', { bubbles: true }));
    }
    this._updateSummary();
    this.options.onApply(finalIds);
    this.options.onChange(finalIds);
    this.close();
  }

  // --- misc ----------------------------------------------------------------

  _esc(s) {
    return String(s == null ? '' : s).replace(
      /[&<>"']/g,
      (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]
    );
  }

  _makeDraggable() {
    const header = this.popup.querySelector('.utility-header');
    if (!header) return;
    let dragging = false;
    let startX;
    let startY;
    let left;
    let top;
    const down = (e) => {
      if (e.target.closest('.utility-close') || e.target.closest('.utility-tools button')) return;
      dragging = true;
      startX = e.clientX;
      startY = e.clientY;
      const rect = this.popup.getBoundingClientRect();
      left = rect.left;
      top = rect.top;
      header.classList.add('dragging');
      e.preventDefault();
    };
    const move = (e) => {
      if (!dragging) return;
      this.popup.style.left = `${left + (e.clientX - startX)}px`;
      this.popup.style.top = `${top + (e.clientY - startY)}px`;
    };
    const up = () => {
      dragging = false;
      header.classList.remove('dragging');
    };
    header.addEventListener('mousedown', down);
    document.addEventListener('mousemove', move);
    document.addEventListener('mouseup', up);
    header.style.cursor = 'grab';
    this.dragCleanup = () => {
      header.removeEventListener('mousedown', down);
      document.removeEventListener('mousemove', move);
      document.removeEventListener('mouseup', up);
    };
  }

  getValue() {
    return Array.from(this.selectedIds);
  }

  setValue(value) {
    this.selectedIds = new Set();
    this._parseValue(value);
    this._updateSummary();
  }

  destroy() {
    this.close();
    if (this.triggerButton && this.summaryDisplay) {
      this.summaryDisplay.parentElement.remove();
    }
  }
}

// Make available globally
window.VisibilityRulesEditor = VisibilityRulesEditor;
